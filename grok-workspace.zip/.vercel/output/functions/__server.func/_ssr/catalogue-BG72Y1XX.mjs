import { h as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue-BG72Y1XX.js
var SplitComponent = Outlet;
//#endregion
export { SplitComponent as component };
