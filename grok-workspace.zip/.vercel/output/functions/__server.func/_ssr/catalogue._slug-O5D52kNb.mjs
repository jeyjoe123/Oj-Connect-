import { i as __toESM } from "../_runtime.mjs";
import { H as require_react, S as require_jsx_runtime, V as notFound, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as zar, S as useBusinessStore, f as PRODUCTS, i as Route$3, p as buttonVariants, u as Button, v as getCategory, x as leadLabel, y as getProduct } from "./router-CbpQT3oa.mjs";
import { n as ProductCard, t as ProductArt } from "./product-card-BiXeM4Rj.mjs";
import { n as Input } from "./input-BSOStgu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue._slug-O5D52kNb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { slug } = Route$3.useParams();
	const product = getProduct(slug);
	if (!product) throw notFound();
	const category = getCategory(product.category);
	const addToBasket = useBusinessStore((s) => s.addToBasket);
	const [qty, setQty] = (0, import_react.useState)(product.minQty);
	const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalogue",
						className: "hover:text-fg",
						children: "Catalogue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-2",
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/catalogue",
						search: { family: product.category },
						className: "hover:text-fg",
						children: category.label
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-8 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductArt, {
					category: product.category,
					seed: product.id,
					className: "aspect-[4/3] w-full rounded-xl"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted",
						children: product.sku
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl tracking-tight sm:text-4xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted",
						children: product.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 font-display text-4xl tabular-nums tracking-tight",
						children: zar(product.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"per ",
							product.unit,
							" · min ",
							product.minQty,
							" · ",
							leadLabel(product.leadDays)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap items-end gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs uppercase tracking-[0.14em] text-muted",
									children: "Quantity"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: product.minQty,
									value: qty,
									className: "w-28",
									onChange: (e) => setQty(Math.max(product.minQty, Number(e.target.value) || product.minQty))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								onClick: () => {
									addToBasket(product, qty);
									toast.success(`Added ${qty} ${product.unit} to quote`);
								},
								children: "Add to quote"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/quote",
								className: buttonVariants({
									variant: "secondary",
									size: "lg"
								}),
								children: "View basket"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-8 grid gap-3 border-t border-border pt-6 text-sm sm:grid-cols-2",
						children: product.specs.map((spec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-surface px-4 py-3 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs uppercase tracking-[0.14em] text-muted",
								children: spec.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: spec.value
							})]
						}, spec.label))
					})
				] })]
			}),
			related.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: ["More in ", category.label]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: related.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
				})]
			}) : null
		]
	});
}
//#endregion
export { ProductPage as component };
