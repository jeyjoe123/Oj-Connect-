import { S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Printer } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as zar, S as useBusinessStore, b as itemsTotal, n as Route, o as EmptyNote, p as buttonVariants, s as PageFrame, u as Button } from "./router-CbpQT3oa.mjs";
import { n as Input, r as Textarea } from "./input-BSOStgu_.mjs";
import { n as QuoteBadge } from "./status-badge-8Oew9vU6.mjs";
import { n as QuoteDocument } from "./documents-CBJMs9UB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ops.quotes._id-DqQVr2_G.js
var import_jsx_runtime = require_jsx_runtime();
var NEXT = [
	{
		status: "new",
		label: "New"
	},
	{
		status: "quoted",
		label: "Quoted"
	},
	{
		status: "awarded",
		label: "Awarded"
	},
	{
		status: "invoiced",
		label: "Invoiced"
	},
	{
		status: "closed",
		label: "Closed"
	}
];
function QuoteDeskPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const enquiry = useBusinessStore((s) => s.enquiries.find((e) => e.id === id));
	const issueQuote = useBusinessStore((s) => s.issueQuote);
	const setEnquiryStatus = useBusinessStore((s) => s.setEnquiryStatus);
	const setItemPrice = useBusinessStore((s) => s.setItemPrice);
	const setItemQty = useBusinessStore((s) => s.setItemQty);
	const setInternalNote = useBusinessStore((s) => s.setInternalNote);
	const raiseInvoice = useBusinessStore((s) => s.raiseInvoice);
	const invoices = useBusinessStore((s) => s.invoices);
	if (!useBusinessStore((s) => s.hydrated)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Quote",
		title: "Loading.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Opening file…"
		})
	});
	if (!enquiry) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Quote",
		title: "Not on the desk.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
			title: "No such enquiry",
			body: "It may have been cleared with the sample restore.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/ops",
				className: buttonVariants(),
				children: "Back to desk"
			})
		})
	});
	const linkedInvoice = invoices.find((i) => i.enquiryId === enquiry.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageFrame, {
		eyebrow: enquiry.number,
		title: enquiry.buyer.org,
		lede: `${enquiry.buyer.contact} · ${enquiry.buyer.email}${enquiry.buyer.reference ? ` · ${enquiry.buyer.reference}` : ""}`,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteBadge, { status: enquiry.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			onClick: () => window.print(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print mb-8 flex flex-wrap gap-2",
				children: NEXT.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setEnquiryStatus(enquiry.id, s.status),
					className: `h-10 rounded-full px-4 text-sm ${enquiry.status === s.status ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]"}`,
					children: s.label
				}, s.status))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mb-8 grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
				children: [enquiry.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-center gap-3 sm:grid-cols-[1fr_5rem_7rem_6rem]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: item.sku
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 1,
							value: item.qty,
							"aria-label": `Qty ${item.name}`,
							onChange: (e) => setItemQty(enquiry.id, item.productId, Number(e.target.value) || 1)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							step: "0.01",
							value: item.unitPrice,
							"aria-label": `Price ${item.name}`,
							onChange: (e) => setItemPrice(enquiry.id, item.productId, Number(e.target.value) || 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-right text-sm tabular-nums",
							children: zar(item.unitPrice * item.qty)
						})
					]
				}, item.productId)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-right font-display text-xl tabular-nums",
					children: zar(itemsTotal(enquiry.items))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mb-8 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs uppercase tracking-[0.14em] text-muted",
						children: "Internal note"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: enquiry.internalNote,
						onChange: (e) => setInternalNote(enquiry.id, e.target.value),
						placeholder: "Delivery, award notes, follow-up"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap content-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								issueQuote(enquiry.id);
								toast.success(`${enquiry.number} issued as a quotation.`);
							},
							children: "Issue quotation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => {
								const invoice = raiseInvoice(enquiry.id);
								if (!invoice) return;
								toast.success(`${invoice.number} raised.`);
								navigate({
									to: "/ops/invoices/$id",
									params: { id: invoice.id }
								});
							},
							children: "Raise invoice"
						}),
						linkedInvoice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/ops/invoices/$id",
							params: { id: linkedInvoice.id },
							className: buttonVariants({ variant: "ghost" }),
							children: ["Open ", linkedInvoice.number]
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteDocument, { enquiry })
		]
	});
}
//#endregion
export { QuoteDeskPage as component };
