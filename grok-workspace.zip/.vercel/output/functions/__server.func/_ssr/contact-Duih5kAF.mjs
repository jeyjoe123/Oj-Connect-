import { i as __toESM } from "../_runtime.mjs";
import { H as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { S as useBusinessStore, c as COMPANY, p as buttonVariants, s as PageFrame, u as Button } from "./router-CbpQT3oa.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-BSOStgu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-Duih5kAF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const addMessage = useBusinessStore((s) => s.addMessage);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		email: "",
		phone: "",
		subject: "",
		body: ""
	});
	const [sent, setSent] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		if (!form.name.trim() || !form.email.trim() || !form.body.trim()) {
			toast.error("Name, email and a message are required.");
			return;
		}
		addMessage(form);
		setSent(true);
		toast.success("Message received on the desk.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Bid office",
		title: "Talk to the desk.",
		lede: `${COMPANY.contact.name} handles quotations from Fish Hoek. Same-day response on working days.`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-[0.85fr_1.15fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-muted",
						children: "Direct"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-2xl",
						children: COMPANY.contact.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: COMPANY.contact.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid gap-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline-offset-4 hover:underline",
								href: `mailto:${COMPANY.contact.email}`,
								children: COMPANY.contact.email
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Phone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: "underline-offset-4 hover:underline",
								href: `tel:${COMPANY.contact.phoneTel}`,
								children: COMPANY.contact.phone
							}) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Office"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [
								COMPANY.street1,
								", ",
								COMPANY.street2,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								COMPANY.city,
								", ",
								COMPANY.postalCode
							] })] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: COMPANY.contact.whatsapp,
						className: `${buttonVariants({ variant: "secondary" })} mt-6`,
						children: "WhatsApp"
					})
				]
			}), sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-8 text-center shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl",
						children: "Received."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"It is logged on the operations desk. For urgent RFQs, WhatsApp or call ",
							COMPANY.contact.phone,
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-6",
						variant: "ghost",
						onClick: () => setSent(false),
						children: "Send another"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								value: form.name,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								type: "email",
								value: form.email,
								onChange: (e) => setForm({
									...form,
									email: e.target.value
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Phone",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.phone,
								onChange: (e) => setForm({
									...form,
									phone: e.target.value
								})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Subject",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: form.subject,
								onChange: (e) => setForm({
									...form,
									subject: e.target.value
								}),
								placeholder: "RFQ, account, delivery"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Message",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							required: true,
							value: form.body,
							onChange: (e) => setForm({
								...form,
								body: e.target.value
							}),
							placeholder: "What do you need supplied, and by when?"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						children: "Send to the desk"
					})
				]
			})]
		})
	});
}
//#endregion
export { ContactPage as component };
