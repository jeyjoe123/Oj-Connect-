import { h as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ops-BYpSyMOG.js
var SplitComponent = Outlet;
//#endregion
export { SplitComponent as component };
