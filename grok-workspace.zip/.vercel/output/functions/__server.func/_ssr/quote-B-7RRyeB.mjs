import { i as __toESM } from "../_runtime.mjs";
import { H as require_react, S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as zar, S as useBusinessStore, b as itemsTotal, o as EmptyNote, p as buttonVariants, s as PageFrame, u as Button } from "./router-CbpQT3oa.mjs";
import { n as Input, r as Textarea, t as Field } from "./input-BSOStgu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-B-7RRyeB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuotePage() {
	const navigate = useNavigate();
	const basket = useBusinessStore((s) => s.basket);
	const setBasketQty = useBusinessStore((s) => s.setBasketQty);
	const removeFromBasket = useBusinessStore((s) => s.removeFromBasket);
	const clearBasket = useBusinessStore((s) => s.clearBasket);
	const submitEnquiry = useBusinessStore((s) => s.submitEnquiry);
	const hydrated = useBusinessStore((s) => s.hydrated);
	const [buyer, setBuyer] = (0, import_react.useState)({
		org: "",
		contact: "",
		email: "",
		phone: "",
		address: "",
		reference: "",
		notes: ""
	});
	const total = itemsTotal(basket);
	function onSubmit(e) {
		e.preventDefault();
		if (!basket.length) return;
		if (!buyer.org.trim() || !buyer.contact.trim() || !buyer.email.trim()) {
			toast.error("Organisation, contact name and email are required.");
			return;
		}
		const enquiry = submitEnquiry(buyer);
		toast.success(`${enquiry.number} is on the desk.`);
		navigate({
			to: "/ops/quotes/$id",
			params: { id: enquiry.id }
		});
	}
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Quote basket",
		title: "Building your RFQ.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading basket…"
		})
	});
	if (!basket.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Quote basket",
		title: "No lines yet.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
			title: "The basket is empty",
			body: "Add SKUs from the catalogue. Minimum order quantities are applied automatically.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/catalogue",
				className: buttonVariants(),
				children: "Browse catalogue"
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Quote basket",
		title: "Request a quotation.",
		lede: "This becomes a numbered enquiry on the OJ CONNECT desk. A 14-day validity is applied when the quote is issued.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			onClick: clearBasket,
			children: "Clear basket"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "grid gap-10 lg:grid-cols-[1.1fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3",
				children: basket.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: item.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								item.sku,
								" · ",
								zar(item.unitPrice),
								" / ",
								item.unit
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								className: "w-24",
								value: item.qty,
								onChange: (e) => setBasketQty(item.productId, Number(e.target.value) || 1),
								"aria-label": `Quantity for ${item.name}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "w-24 text-right tabular-nums",
								children: zar(item.unitPrice * item.qty)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => removeFromBasket(item.productId),
								children: "Remove"
							})
						]
					})]
				}, item.productId))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center justify-between border-t border-border pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Estimated total (no VAT)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tabular-nums",
					children: zar(total)
				})]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: "Buyer details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Organisation",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								value: buyer.org,
								onChange: (e) => setBuyer({
									...buyer,
									org: e.target.value
								}),
								placeholder: "Department, school or company"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Contact name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								value: buyer.contact,
								onChange: (e) => setBuyer({
									...buyer,
									contact: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									type: "email",
									value: buyer.email,
									onChange: (e) => setBuyer({
										...buyer,
										email: e.target.value
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: buyer.phone,
									onChange: (e) => setBuyer({
										...buyer,
										phone: e.target.value
									})
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Delivery address",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: buyer.address,
								onChange: (e) => setBuyer({
									...buyer,
									address: e.target.value
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Your RFQ / order reference",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: buyer.reference,
								onChange: (e) => setBuyer({
									...buyer,
									reference: e.target.value
								}),
								placeholder: "RFQ-…"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Notes",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: buyer.notes,
								onChange: (e) => setBuyer({
									...buyer,
									notes: e.target.value
								}),
								placeholder: "Sizes, colours, site access, delivery window"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							children: "Submit RFQ"
						})
					]
				})]
			})]
		})
	});
}
//#endregion
export { QuotePage as component };
