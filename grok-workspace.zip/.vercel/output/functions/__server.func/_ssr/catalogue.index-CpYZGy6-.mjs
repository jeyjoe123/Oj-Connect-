import { i as __toESM } from "../_runtime.mjs";
import { H as require_react, S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$4, d as CATEGORIES, f as PRODUCTS, m as cn, s as PageFrame } from "./router-CbpQT3oa.mjs";
import { n as ProductCard } from "./product-card-BiXeM4Rj.mjs";
import { n as Input } from "./input-BSOStgu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalogue.index-CpYZGy6-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CataloguePage() {
	const { family } = Route$4.useSearch();
	const [q, setQ] = (0, import_react.useState)("");
	const active = family;
	const items = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return PRODUCTS.filter((p) => {
			if (active && p.category !== active) return false;
			if (!needle) return true;
			return p.name.toLowerCase().includes(needle) || p.sku.toLowerCase().includes(needle) || p.summary.toLowerCase().includes(needle);
		});
	}, [active, q]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageFrame, {
		eyebrow: "Catalogue",
		title: "Stock specified for public and private buyers.",
		lede: "Prices are in rand, exclusive of VAT. Minimum order quantities apply. Add lines to a quote and send it from the basket.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyChip, {
						to: "/catalogue",
						search: { family: void 0 },
						active: !active,
						label: "All families"
					}), CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FamilyChip, {
						to: "/catalogue",
						search: { family: cat.id },
						active: active === cat.id,
						label: cat.label
					}, cat.id))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search name or SKU",
					className: "lg:max-w-xs",
					"aria-label": "Search catalogue"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-muted",
				children: [
					items.length,
					" SKU",
					items.length === 1 ? "" : "s",
					active ? ` in ${CATEGORIES.find((c) => c.id === active)?.label}` : ""
				]
			}),
			items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "No stock matches that search."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: p }, p.id))
			})
		]
	});
}
function FamilyChip({ to, search, active, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		search,
		className: cn("inline-flex h-11 items-center rounded-full px-4 text-sm transition-colors duration-150", active ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg"),
		children: label
	});
}
//#endregion
export { CataloguePage as component };
