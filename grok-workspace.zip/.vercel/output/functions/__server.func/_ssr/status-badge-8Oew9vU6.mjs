import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Badge } from "./badge-BmBFXzKz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-badge-8Oew9vU6.js
var import_jsx_runtime = require_jsx_runtime();
var quoteTone = {
	new: "warn",
	quoted: "live",
	awarded: "paper",
	invoiced: "live",
	closed: "mute"
};
var quoteLabel = {
	new: "New enquiry",
	quoted: "Quoted",
	awarded: "Awarded",
	invoiced: "Invoiced",
	closed: "Closed"
};
function QuoteBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: quoteTone[status],
		children: quoteLabel[status]
	});
}
function InvoiceBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: status === "paid" ? "live" : "warn",
		children: status === "paid" ? "Paid" : "Issued"
	});
}
//#endregion
export { QuoteBadge as n, InvoiceBadge as t };
