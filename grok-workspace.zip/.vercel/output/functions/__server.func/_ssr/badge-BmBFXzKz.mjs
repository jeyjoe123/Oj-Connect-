import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as cn } from "./router-CbpQT3oa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-BmBFXzKz.js
var import_jsx_runtime = require_jsx_runtime();
var tones = {
	mute: "bg-elevated text-muted",
	live: "bg-primary/15 text-primary",
	paper: "bg-cream/10 text-cream",
	warn: "bg-warn/15 text-warn",
	danger: "bg-danger/15 text-danger"
};
function Badge({ tone = "mute", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium uppercase tracking-[0.12em]", tones[tone], className),
		...props
	});
}
//#endregion
export { Badge as t };
