import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as zar, S as useBusinessStore, b as itemsTotal, g as formatDate, m as cn, o as EmptyNote, p as buttonVariants, s as PageFrame, u as Button } from "./router-CbpQT3oa.mjs";
import { n as QuoteBadge, t as InvoiceBadge } from "./status-badge-8Oew9vU6.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ops.index-Dg7GHh69.js
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"new",
	"quoted",
	"awarded",
	"invoiced",
	"closed"
];
function OpsPage() {
	const enquiries = useBusinessStore((s) => s.enquiries);
	const invoices = useBusinessStore((s) => s.invoices);
	const messages = useBusinessStore((s) => s.messages);
	const markMessageRead = useBusinessStore((s) => s.markMessageRead);
	const restoreSample = useBusinessStore((s) => s.restoreSample);
	const hydrated = useBusinessStore((s) => s.hydrated);
	const openValue = enquiries.filter((e) => e.status === "new" || e.status === "quoted").reduce((n, e) => n + itemsTotal(e.items), 0);
	const awardedValue = enquiries.filter((e) => e.status === "awarded" || e.status === "invoiced").reduce((n, e) => n + itemsTotal(e.items), 0);
	const outstanding = invoices.filter((i) => i.status === "issued").reduce((n, i) => n + itemsTotal(i.items), 0);
	const unread = messages.filter((m) => !m.read).length;
	const chart = STATUSES.map((status) => ({
		status,
		value: enquiries.filter((e) => e.status === status).reduce((n, e) => n + itemsTotal(e.items), 0),
		count: enquiries.filter((e) => e.status === status).length
	}));
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Operations desk",
		title: "Opening the books.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Loading pipeline…"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageFrame, {
		eyebrow: "Operations desk",
		title: "Quotes, invoices, messages.",
		lede: "This desk is the working copy of OJ CONNECT — RFQs in, quotations out, invoices raised. Sample pipeline is loaded so you can run it immediately.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "secondary",
			onClick: restoreSample,
			children: "Restore sample pipeline"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Open RFQ value",
						value: zar(openValue),
						hint: `${enquiries.filter((e) => e.status === "new" || e.status === "quoted").length} live`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Awarded / invoiced",
						value: zar(awardedValue),
						hint: "Won work"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Invoices outstanding",
						value: zar(outstanding),
						hint: `${invoices.filter((i) => i.status === "issued").length} issued`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Unread messages",
						value: String(unread),
						hint: `${messages.length} total`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-muted",
					children: "Pipeline value by status"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: chart,
							margin: {
								top: 8,
								right: 8,
								left: 0,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "status",
									stroke: "var(--color-muted)",
									fontSize: 11,
									tickLine: false,
									axisLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									stroke: "var(--color-muted)",
									fontSize: 11,
									tickLine: false,
									axisLine: false,
									tickFormatter: (v) => v >= 1e3 ? `${Math.round(v / 1e3)}k` : String(v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									cursor: { fill: "color-mix(in oklab, var(--color-fg) 4%, transparent)" },
									contentStyle: {
										background: "var(--color-surface)",
										border: "1px solid var(--color-border)",
										borderRadius: 12,
										color: "var(--color-fg)"
									},
									formatter: (value) => zar(Number(value ?? 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "value",
									fill: "var(--color-primary)",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-10 lg:grid-cols-[1.2fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl tracking-tight",
					children: "Enquiries"
				}), enquiries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
						title: "No enquiries",
						body: "Submit an RFQ from the catalogue, or restore the sample pipeline."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
					children: enquiries.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/ops/quotes/$id",
						params: { id: e.id },
						className: "flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: e.buyer.org
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								e.number,
								" · ",
								formatDate(e.createdAt),
								" · ",
								e.items.length,
								" lines"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-sm",
								children: zar(itemsTotal(e.items))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteBadge, { status: e.status })]
						})]
					}) }, e.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Invoices"
					}), invoices.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "No invoices raised yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
						children: invoices.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/ops/invoices/$id",
							params: { id: inv.id },
							className: "flex items-center justify-between gap-3 px-4 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: inv.number
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: inv.buyer.org
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-sm",
									children: zar(itemsTotal(inv.items))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceBadge, { status: inv.status })]
							})]
						}) }, inv.id))
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Inbox"
					}), messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Contact form messages land here."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-3",
						children: messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]", !m.read && "ring-1 ring-primary/40"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: m.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: [
											m.email,
											" · ",
											formatDate(m.createdAt)
										]
									})] }), !m.read ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "ghost",
										onClick: () => markMessageRead(m.id),
										children: "Mark read"
									}) : null]
								}),
								m.subject ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm",
									children: m.subject
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: m.body
								})
							]
						}, m.id))
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/catalogue",
					className: buttonVariants({ variant: "secondary" }),
					children: "Raise a new RFQ from catalogue"
				})
			})
		]
	});
}
function Kpi({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.14em] text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-2xl tabular-nums tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-subtle",
				children: hint
			})
		]
	});
}
//#endregion
export { OpsPage as component };
