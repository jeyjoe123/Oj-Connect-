import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as zar, S as useBusinessStore, m as cn, p as buttonVariants, v as getCategory, x as leadLabel } from "./router-CbpQT3oa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-card-BiXeM4Rj.js
var import_jsx_runtime = require_jsx_runtime();
var palettes = {
	clothing: {
		a: "var(--color-elevated)",
		b: "var(--color-primary)",
		c: "var(--color-cream)"
	},
	footwear: {
		a: "var(--color-surface)",
		b: "var(--color-muted)",
		c: "var(--color-cream)"
	},
	network: {
		a: "var(--color-elevated)",
		b: "var(--color-primary)",
		c: "var(--color-fg)"
	},
	office: {
		a: "var(--color-surface)",
		b: "var(--color-muted)",
		c: "var(--color-paper)"
	},
	security: {
		a: "var(--color-bg)",
		b: "var(--color-muted)",
		c: "var(--color-cream)"
	},
	furniture: {
		a: "var(--color-elevated)",
		b: "var(--color-subtle)",
		c: "var(--color-cream)"
	}
};
function ProductArt({ category, seed, className }) {
	const p = palettes[category];
	const n = seed.split("").reduce((a, ch) => a + ch.charCodeAt(0), 0);
	const rot = n % 18 - 9;
	const ox = 8 + n % 10;
	const oy = 6 + n * 3 % 12;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative overflow-hidden rounded-lg bg-elevated", className),
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 160 110",
			className: "size-full",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "160",
				height: "110",
				fill: p.a
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				transform: `translate(${ox} ${oy}) rotate(${rot} 70 50)`,
				children: [
					category === "clothing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M40 28 L70 18 L100 28 L92 42 L92 88 L48 88 L48 42 Z",
							fill: p.b
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M70 18 L78 34 L62 34 Z",
							fill: p.c,
							opacity: "0.7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "48",
							y: "54",
							width: "44",
							height: "6",
							fill: p.c,
							opacity: "0.35"
						})
					] }) : null,
					category === "footwear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M28 64 C48 44, 78 44, 118 58 L122 70 C90 78, 50 80, 30 72 Z",
							fill: p.b
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M34 66 C52 52, 86 52, 116 62",
							fill: "none",
							stroke: p.c,
							strokeWidth: "3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "36",
							y: "68",
							width: "70",
							height: "6",
							rx: "3",
							fill: p.a,
							opacity: "0.4"
						})
					] }) : null,
					category === "network" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "36",
						y: "30",
						width: "88",
						height: "52",
						rx: "6",
						fill: p.b
					}), Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: 46 + i % 4 * 18,
						y: 40 + Math.floor(i / 4) * 18,
						width: "10",
						height: "10",
						rx: "1.5",
						fill: p.c,
						opacity: .45 + (n + i) % 4 * .12
					}, i))] }) : null,
					category === "office" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "42",
							y: "24",
							width: "70",
							height: "62",
							fill: p.c
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "50",
							y: "32",
							width: "54",
							height: "6",
							fill: p.b,
							opacity: "0.5"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "50",
							y: "44",
							width: "40",
							height: "4",
							fill: p.a,
							opacity: "0.35"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "50",
							y: "54",
							width: "46",
							height: "4",
							fill: p.a,
							opacity: "0.25"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "50",
							y: "64",
							width: "30",
							height: "4",
							fill: p.a,
							opacity: "0.2"
						})
					] }) : null,
					category === "security" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "80",
							cy: "52",
							r: "28",
							fill: p.b
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "80",
							cy: "52",
							r: "14",
							fill: p.a
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "80",
							cy: "52",
							r: "6",
							fill: p.c
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "76",
							y: "18",
							width: "8",
							height: "12",
							fill: p.c
						})
					] }) : null,
					category === "furniture" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "34",
							y: "48",
							width: "92",
							height: "28",
							rx: "3",
							fill: p.b
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "40",
							y: "34",
							width: "24",
							height: "18",
							rx: "2",
							fill: p.c
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "96",
							y: "34",
							width: "24",
							height: "18",
							rx: "2",
							fill: p.c
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "40",
							y: "76",
							width: "8",
							height: "16",
							fill: p.a
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "112",
							y: "76",
							width: "8",
							height: "16",
							fill: p.a
						})
					] }) : null
				]
			})]
		})
	});
}
function ProductCard({ product }) {
	const addToBasket = useBusinessStore((s) => s.addToBasket);
	const category = getCategory(product.category);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col rounded-xl bg-surface p-2 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/catalogue/$slug",
			params: { slug: product.slug },
			className: "block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductArt, {
				category: product.category,
				seed: product.id,
				className: "aspect-video w-full"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col px-3 pb-3 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.14em] text-muted",
					children: category.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/catalogue/$slug",
					params: { slug: product.slug },
					className: "mt-1 font-medium text-fg",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 line-clamp-2 text-sm text-muted",
					children: product.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex items-end justify-between gap-3 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl tabular-nums tracking-tight",
						children: zar(product.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-subtle",
						children: [
							"/ ",
							product.unit,
							" · ",
							leadLabel(product.leadDays)
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: buttonVariants({
							variant: "primary",
							size: "sm"
						}),
						onClick: () => {
							addToBasket(product);
							toast.success(`Added ${product.name} to quote`);
						},
						children: "Add"
					})]
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as n, ProductArt as t };
