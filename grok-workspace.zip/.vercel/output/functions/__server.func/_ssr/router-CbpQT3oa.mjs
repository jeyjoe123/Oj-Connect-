import { i as __toESM } from "../_runtime.mjs";
import { H as require_react, S as require_jsx_runtime, _ as createFileRoute, d as HeadContent, f as useRouterState, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as Menu, n as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as string, i as object, n as literal, o as union, r as number, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-BWfjrAT5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium whitespace-nowrap select-none transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-surface text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "text-fg hover:bg-elevated",
			outline: "text-fg shadow-[var(--shadow-border)] hover:bg-elevated",
			paper: "bg-paper text-ink hover:opacity-90",
			danger: "bg-danger text-paper hover:opacity-90"
		},
		size: {
			sm: "h-10 min-h-10 px-3.5 text-sm rounded-md",
			md: "h-11 min-h-11 px-4 text-sm rounded-lg",
			lg: "h-12 min-h-12 px-5 text-base rounded-xl"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
var CATEGORIES = [
	{
		id: "clothing",
		label: "Clothing",
		csdFamily: "Clothing",
		blurb: "Corporate wear, staff uniforms and branded garments for departments and sites."
	},
	{
		id: "footwear",
		label: "Footwear",
		csdFamily: "Footwear",
		blurb: "Safety boots and duty shoes specified for municipal, school and site work."
	},
	{
		id: "network",
		label: "Network & ICT",
		csdFamily: "Data Voice or Multimedia Network Equipment or Platforms and Accessories",
		blurb: "Switches, cabling, Wi-Fi, UPS and voice hardware for offices and campuses."
	},
	{
		id: "office",
		label: "Office supply",
		csdFamily: "Office supplies — (Office supply)",
		blurb: "Paper, toner, stationery and filing — the daily stock that keeps a bid running."
	},
	{
		id: "security",
		label: "Security & surveillance",
		csdFamily: "Security surveillance and detection",
		blurb: "CCTV, NVR kits, alarms and access control for buildings and yards."
	},
	{
		id: "furniture",
		label: "Accommodation furniture",
		csdFamily: "Accommodation furniture",
		blurb: "Beds, wardrobes, desks and lodge seating for hostels, guesthouses and sites."
	}
];
var PRODUCTS = [
	{
		id: "polo-navy",
		slug: "corporate-polo-navy",
		sku: "OJC-CLO-001",
		name: "Corporate polo — navy",
		category: "clothing",
		summary: "Pique cotton polo with chest embroidery window. Standard municipal colours.",
		description: "180 gsm pique polo with taped neck, split hem and a 80 × 40 mm embroidery window. Used for staff, events and site identification. Colour-matched lots available on RFQ.",
		unit: "each",
		price: 189,
		minQty: 10,
		leadDays: 10,
		featured: true,
		specs: [
			{
				label: "Fabric",
				value: "180 gsm pique cotton"
			},
			{
				label: "Sizes",
				value: "XS–5XL"
			},
			{
				label: "Branding",
				value: "Embroidery or heat transfer"
			},
			{
				label: "MOQ",
				value: "10 units"
			}
		]
	},
	{
		id: "staff-uniform",
		slug: "two-piece-staff-uniform",
		sku: "OJC-CLO-002",
		name: "Two-piece staff uniform",
		category: "clothing",
		summary: "Shirt and trouser set for reception, clinics and municipal counters.",
		description: "Easy-care poly-cotton shirt with matching tailored trousers. Supplied as a numbered set per wearer. Alternate fabrics quoted for healthcare and kitchen use.",
		unit: "set",
		price: 620,
		minQty: 5,
		leadDays: 12,
		featured: false,
		specs: [
			{
				label: "Fabric",
				value: "Poly-cotton easy care"
			},
			{
				label: "Includes",
				value: "Shirt + trouser"
			},
			{
				label: "Sizing",
				value: "Made to size chart"
			}
		]
	},
	{
		id: "hivis-jacket",
		slug: "hi-vis-work-jacket",
		sku: "OJC-CLO-003",
		name: "Hi-vis work jacket",
		category: "clothing",
		summary: "Class 2 high-visibility jacket with reflective tape for roads and yards.",
		description: "Waterproof outer with taped seams and 50 mm reflective bands. Issued to field teams and contractors. Logo application quoted separately.",
		unit: "each",
		price: 349,
		minQty: 5,
		leadDays: 7,
		featured: false,
		specs: [
			{
				label: "Class",
				value: "SANS 50471 Class 2"
			},
			{
				label: "Colour",
				value: "Fluoro lime / navy"
			},
			{
				label: "Weather",
				value: "Waterproof taped seams"
			}
		]
	},
	{
		id: "branded-caps",
		slug: "branded-cap-pack",
		sku: "OJC-CLO-004",
		name: "Branded cap pack (10)",
		category: "clothing",
		summary: "Structured six-panel caps, packed in tens for events and teams.",
		description: "Heavy brushed cotton cap with sandwich peak and adjustable strap. Sold in packs of ten. One-colour embroidery included in the pack price.",
		unit: "pack",
		price: 450,
		minQty: 1,
		leadDays: 8,
		featured: false,
		specs: [
			{
				label: "Pack size",
				value: "10 caps"
			},
			{
				label: "Branding",
				value: "1-colour embroidery included"
			},
			{
				label: "Closure",
				value: "Adjustable strap"
			}
		]
	},
	{
		id: "safety-boots",
		slug: "sabs-safety-boots",
		sku: "OJC-FTW-001",
		name: "SABS steel-toe safety boots",
		category: "footwear",
		summary: "Leather work boot with steel toe cap and oil-resistant sole.",
		description: "Full-grain leather boot specified for workshops, parks and construction stores. Steel toe, midsole puncture resistance and an oil-resistant rubber outsole.",
		unit: "pair",
		price: 789,
		minQty: 5,
		leadDays: 5,
		featured: true,
		specs: [
			{
				label: "Standard",
				value: "SANS 20345"
			},
			{
				label: "Toe cap",
				value: "Steel"
			},
			{
				label: "Sizes",
				value: "3–13 UK"
			}
		]
	},
	{
		id: "oxford-duty",
		slug: "corporate-oxford-shoe",
		sku: "OJC-FTW-002",
		name: "Corporate oxford — black",
		category: "footwear",
		summary: "Duty oxford for office, court and front-of-house staff.",
		description: "Leather upper with a non-marking sole. A quieter alternative to a safety boot for indoor posts. Supplied boxed per pair.",
		unit: "pair",
		price: 560,
		minQty: 4,
		leadDays: 7,
		featured: false,
		specs: [
			{
				label: "Upper",
				value: "Genuine leather"
			},
			{
				label: "Colour",
				value: "Black"
			},
			{
				label: "Sole",
				value: "Non-marking"
			}
		]
	},
	{
		id: "school-leather",
		slug: "school-leather-shoe",
		sku: "OJC-FTW-003",
		name: "School leather shoe",
		category: "footwear",
		summary: "Plain black leather school shoe in bulk size runs.",
		description: "Traditional round-toe school shoe with a scuff-resistant finish. Quoted by size run for schools and hostels.",
		unit: "pair",
		price: 320,
		minQty: 10,
		leadDays: 10,
		featured: false,
		specs: [
			{
				label: "Finish",
				value: "Scuff-resistant black"
			},
			{
				label: "Sizes",
				value: "1–12 UK"
			},
			{
				label: "Supply",
				value: "Size-run packing"
			}
		]
	},
	{
		id: "gig-switch",
		slug: "24-port-gigabit-switch",
		sku: "OJC-NET-001",
		name: "24-port gigabit switch",
		category: "network",
		summary: "Unmanaged 24-port gigabit switch for office floors and server rooms.",
		description: "Fanless 24× 10/100/1000 RJ45 switch in a 1U metal chassis. Used as the workhorse edge switch on municipal and school networks.",
		unit: "each",
		price: 1890,
		minQty: 1,
		leadDays: 5,
		featured: true,
		specs: [
			{
				label: "Ports",
				value: "24 × Gigabit RJ45"
			},
			{
				label: "Form",
				value: "1U metal, fanless"
			},
			{
				label: "Mount",
				value: "Rack ears included"
			}
		]
	},
	{
		id: "cat6-drum",
		slug: "cat6-utp-305m-drum",
		sku: "OJC-NET-002",
		name: "Cat6 UTP 305 m drum",
		category: "network",
		summary: "Solid-core Cat6 on a 305 metre pull box for structured cabling.",
		description: "23 AWG solid copper Cat6, 250 MHz, supplied on a 305 m reel. Flame-rated jacket suitable for office risers.",
		unit: "drum",
		price: 2450,
		minQty: 1,
		leadDays: 4,
		featured: false,
		specs: [
			{
				label: "Length",
				value: "305 m"
			},
			{
				label: "Conductor",
				value: "23 AWG solid Cu"
			},
			{
				label: "Rating",
				value: "Cat6 / 250 MHz"
			}
		]
	},
	{
		id: "wifi6-ap",
		slug: "wifi-6-access-point",
		sku: "OJC-NET-003",
		name: "Wi-Fi 6 access point",
		category: "network",
		summary: "Ceiling AP with PoE for classrooms, clinics and open-plan floors.",
		description: "Dual-band Wi-Fi 6 access point with gigabit PoE. Ceiling or wall mount. Controller optional — works standalone for small sites.",
		unit: "each",
		price: 1650,
		minQty: 2,
		leadDays: 6,
		featured: false,
		specs: [
			{
				label: "Radio",
				value: "Wi-Fi 6 dual-band"
			},
			{
				label: "Uplink",
				value: "1G PoE"
			},
			{
				label: "Mount",
				value: "Ceiling / wall"
			}
		]
	},
	{
		id: "ups-1kva",
		slug: "1kva-line-interactive-ups",
		sku: "OJC-NET-004",
		name: "1 kVA line-interactive UPS",
		category: "network",
		summary: "Tower UPS for a reception PC, till or small switch stack.",
		description: "Line-interactive UPS with AVR, USB signalling and a lead-acid battery. Covers short Cape Town load events for a single workstation or 8-port switch.",
		unit: "each",
		price: 2100,
		minQty: 1,
		leadDays: 5,
		featured: false,
		specs: [
			{
				label: "Capacity",
				value: "1 kVA / 600 W"
			},
			{
				label: "Topology",
				value: "Line-interactive + AVR"
			},
			{
				label: "Outlets",
				value: "4 × SA 3-pin"
			}
		]
	},
	{
		id: "ip-phone",
		slug: "ip-desk-phone",
		sku: "OJC-NET-005",
		name: "IP desk phone",
		category: "network",
		summary: "PoE handset for switchboards, clinics and bid offices.",
		description: "Two-line IP phone with a backlit display and a gigabit pass-through port. Provisioned against most hosted PABX platforms.",
		unit: "each",
		price: 890,
		minQty: 2,
		leadDays: 6,
		featured: false,
		specs: [
			{
				label: "Lines",
				value: "2 SIP accounts"
			},
			{
				label: "Power",
				value: "PoE or PSU"
			},
			{
				label: "Network",
				value: "Gigabit PC port"
			}
		]
	},
	{
		id: "a4-carton",
		slug: "a4-copy-paper-carton",
		sku: "OJC-OFF-001",
		name: "A4 copy paper — 5-ream carton",
		category: "office",
		summary: "80 gsm white bond, five reams to a carton. The standing stationery buy.",
		description: "80 gsm white A4, 500 sheets per ream, five reams per carton. Suitable for copiers and laser printers used in bid offices.",
		unit: "carton",
		price: 429,
		minQty: 4,
		leadDays: 3,
		featured: true,
		specs: [
			{
				label: "Weight",
				value: "80 gsm"
			},
			{
				label: "Pack",
				value: "5 × 500 sheets"
			},
			{
				label: "Size",
				value: "A4"
			}
		]
	},
	{
		id: "toner-pack",
		slug: "compatible-toner-pack",
		sku: "OJC-OFF-002",
		name: "Compatible toner pack",
		category: "office",
		summary: "High-yield compatible cartridges quoted against your printer list.",
		description: "Compatible laser toner packed per model. Send the printer fleet list with the RFQ and we match yield and fitment. Originals quoted on request.",
		unit: "pack",
		price: 780,
		minQty: 1,
		leadDays: 4,
		featured: false,
		specs: [
			{
				label: "Type",
				value: "Compatible laser"
			},
			{
				label: "Match",
				value: "Against fleet list"
			},
			{
				label: "Yield",
				value: "High-yield where available"
			}
		]
	},
	{
		id: "stationery-kit",
		slug: "executive-stationery-kit",
		sku: "OJC-OFF-003",
		name: "Desk stationery kit",
		category: "office",
		summary: "Pens, folders, clips and pads packed as a new-starter kit.",
		description: "A counted kit for a new desk: writing instruments, A4 pads, suspension files, clips and a stapler. Used for onboarding and satellite offices.",
		unit: "kit",
		price: 245,
		minQty: 5,
		leadDays: 3,
		featured: false,
		specs: [{
			label: "Contents",
			value: "Counted 18-item kit"
		}, {
			label: "Use",
			value: "New starter / satellite"
		}]
	},
	{
		id: "filing-cabinet",
		slug: "four-drawer-filing-cabinet",
		sku: "OJC-OFF-004",
		name: "Four-drawer filing cabinet",
		category: "office",
		summary: "Lockable steel cabinet for personnel and tender files.",
		description: "Fully assembled steel cabinet with anti-tilt and a lock bar. Foolscap hanging files sit flush. Powder-coated in grey.",
		unit: "each",
		price: 2890,
		minQty: 1,
		leadDays: 8,
		featured: false,
		specs: [
			{
				label: "Drawers",
				value: "4 foolscap"
			},
			{
				label: "Lock",
				value: "Central lock bar"
			},
			{
				label: "Finish",
				value: "Grey powder coat"
			}
		]
	},
	{
		id: "nvr-kit",
		slug: "eight-channel-nvr-camera-kit",
		sku: "OJC-SEC-001",
		name: "8-channel NVR kit + 4 cameras",
		category: "security",
		summary: "PoE NVR with four 4 MP turrets, 1 TB storage and night IR.",
		description: "A starter site kit: 8-channel PoE NVR, four 4 MP turret cameras, 1 TB disk and 20 m patch leads. Expandable to eight cameras on the same recorder.",
		unit: "kit",
		price: 6450,
		minQty: 1,
		leadDays: 6,
		featured: true,
		specs: [
			{
				label: "Recorder",
				value: "8-ch PoE NVR"
			},
			{
				label: "Cameras",
				value: "4 × 4 MP turret"
			},
			{
				label: "Storage",
				value: "1 TB included"
			}
		]
	},
	{
		id: "turret-4mp",
		slug: "4mp-turret-camera",
		sku: "OJC-SEC-002",
		name: "4 MP turret camera",
		category: "security",
		summary: "IP turret with 30 m IR for yards, corridors and parking.",
		description: "Metal turret, 4 MP, 2.8 mm lens, 30 m IR. PoE. Used as a drop-in extra on the 8-channel kit or as a replacement head.",
		unit: "each",
		price: 890,
		minQty: 2,
		leadDays: 5,
		featured: false,
		specs: [
			{
				label: "Sensor",
				value: "4 MP"
			},
			{
				label: "IR",
				value: "30 m"
			},
			{
				label: "Power",
				value: "PoE"
			}
		]
	},
	{
		id: "alarm-kit",
		slug: "wireless-alarm-kit",
		sku: "OJC-SEC-003",
		name: "Wireless alarm kit",
		category: "security",
		summary: "Panel, keypad, PIR and door contacts for a small building.",
		description: "App-connected wireless alarm with a keypad, two PIRs, two door contacts and a siren. Suitable for a satellite office or storeroom.",
		unit: "kit",
		price: 2150,
		minQty: 1,
		leadDays: 5,
		featured: false,
		specs: [{
			label: "Includes",
			value: "Panel, keypad, 2 PIR, 2 contacts, siren"
		}, {
			label: "App",
			value: "iOS / Android"
		}]
	},
	{
		id: "access-rfid",
		slug: "rfid-access-control-kit",
		sku: "OJC-SEC-004",
		name: "RFID access control kit",
		category: "security",
		summary: "Single-door controller, reader, lock and ten fobs.",
		description: "A complete single-door kit: controller, Wiegand reader, magnetic lock, override key and ten fobs. Extra doors quoted per opening.",
		unit: "kit",
		price: 3200,
		minQty: 1,
		leadDays: 7,
		featured: false,
		specs: [
			{
				label: "Doors",
				value: "1 (expandable)"
			},
			{
				label: "Lock",
				value: "Maglock included"
			},
			{
				label: "Fobs",
				value: "10"
			}
		]
	},
	{
		id: "bed-set",
		slug: "single-bed-mattress-set",
		sku: "OJC-FUR-001",
		name: "Single bed + mattress set",
		category: "furniture",
		summary: "Steel-frame single with a medium-firm inner-spring mattress.",
		description: "Powder-coated steel single bed with a 137 mm inner-spring mattress. Specified for hostels, lodges and site accommodation. Stackable headboards optional.",
		unit: "set",
		price: 3450,
		minQty: 2,
		leadDays: 10,
		featured: true,
		specs: [
			{
				label: "Size",
				value: "Single 92 × 188 cm"
			},
			{
				label: "Mattress",
				value: "Inner spring, medium"
			},
			{
				label: "Frame",
				value: "Steel, powder coated"
			}
		]
	},
	{
		id: "wardrobe-3",
		slug: "three-door-wardrobe",
		sku: "OJC-FUR-002",
		name: "Three-door wardrobe",
		category: "furniture",
		summary: "Melamine wardrobe with hanging rail and two shelves.",
		description: "16 mm melamine three-door wardrobe, hanging rail on the left, two shelves on the right. Knock-down packed for site delivery.",
		unit: "each",
		price: 4890,
		minQty: 1,
		leadDays: 12,
		featured: false,
		specs: [
			{
				label: "Board",
				value: "16 mm melamine"
			},
			{
				label: "Doors",
				value: "3"
			},
			{
				label: "Pack",
				value: "Knock-down"
			}
		]
	},
	{
		id: "study-desk",
		slug: "study-desk-and-chair",
		sku: "OJC-FUR-003",
		name: "Study desk + chair",
		category: "furniture",
		summary: "Compact desk and stacking chair for hostels and training rooms.",
		description: "1 200 mm melamine desk with a steel-frame stacking chair. Used in residences, training rooms and bid-office overflow.",
		unit: "set",
		price: 2150,
		minQty: 2,
		leadDays: 9,
		featured: false,
		specs: [{
			label: "Desk",
			value: "1 200 × 600 mm"
		}, {
			label: "Chair",
			value: "Stacking, steel frame"
		}]
	},
	{
		id: "lodge-sofa",
		slug: "three-seater-lodge-sofa",
		sku: "OJC-FUR-004",
		name: "Three-seater lodge sofa",
		category: "furniture",
		summary: "Contract fabric sofa for lounges, waiting rooms and guesthouses.",
		description: "Hardwood frame, high-density foam and a contract-grade fabric. Specified for waiting rooms and lodge lounges that take daily traffic.",
		unit: "each",
		price: 6200,
		minQty: 1,
		leadDays: 14,
		featured: false,
		specs: [
			{
				label: "Seats",
				value: "3"
			},
			{
				label: "Fabric",
				value: "Contract grade"
			},
			{
				label: "Frame",
				value: "Hardwood"
			}
		]
	}
];
function getCategory(id) {
	return CATEGORIES.find((c) => c.id === id);
}
function getProduct(slug) {
	return PRODUCTS.find((p) => p.slug === slug);
}
function featuredProducts() {
	return PRODUCTS.filter((p) => p.featured);
}
function zar(value) {
	return new Intl.NumberFormat("en-ZA", {
		style: "currency",
		currency: "ZAR",
		minimumFractionDigits: 2
	}).format(value);
}
function formatDate(iso) {
	return new Intl.DateTimeFormat("en-ZA", {
		day: "2-digit",
		month: "short",
		year: "numeric"
	}).format(new Date(iso));
}
function formatDateLong(iso) {
	return new Intl.DateTimeFormat("en-ZA", {
		day: "numeric",
		month: "long",
		year: "numeric"
	}).format(new Date(iso));
}
function daysFromNow(days) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() + days);
	return d.toISOString();
}
function leadLabel(days) {
	if (days <= 1) return "Next working day";
	return `${days} working days`;
}
function pad(n) {
	return String(n).padStart(4, "0");
}
function lineFromProduct(product, qty) {
	return {
		productId: product.id,
		name: product.name,
		sku: product.sku,
		unit: product.unit,
		unitPrice: product.price,
		qty
	};
}
function findProduct(id) {
	return PRODUCTS.find((p) => p.id === id);
}
var SEED_ENQUIRIES = [
	{
		id: "enq-1",
		number: "Q-2026-0001",
		createdAt: "2026-09-12T09:14:00.000Z",
		status: "awarded",
		validUntil: "2026-09-26T00:00:00.000Z",
		internalNote: "Awarded against City of Cape Town RFQ-PRK-441. Delivery to Fish Hoek depot.",
		buyer: {
			org: "City of Cape Town — Parks & Recreation",
			contact: "Lindiwe September",
			email: "procurement.parks@capetown.gov.za",
			phone: "021 400 1111",
			address: "Civic Centre, 12 Hertzog Boulevard, Cape Town, 8001",
			reference: "RFQ-PRK-441",
			notes: "Hi-vis and safety boots for the southern peninsula crew. Delivered to Fish Hoek depot."
		},
		items: [lineFromProduct(findProduct("hivis-jacket"), 24), lineFromProduct(findProduct("safety-boots"), 24)]
	},
	{
		id: "enq-2",
		number: "Q-2026-0002",
		createdAt: "2026-09-18T11:40:00.000Z",
		status: "quoted",
		validUntil: "2026-10-02T00:00:00.000Z",
		internalNote: "Waiting on SGB sign-off.",
		buyer: {
			org: "Fish Hoek Primary School",
			contact: "Thabo Ndlovu",
			email: "admin@fishhoekps.wcape.school.za",
			phone: "021 782 2104",
			address: "18 2nd Avenue, Fish Hoek, 7975",
			reference: "SGB-STAT-09",
			notes: "Term-four stationery and two filing cabinets for the office."
		},
		items: [
			lineFromProduct(findProduct("a4-carton"), 12),
			lineFromProduct(findProduct("stationery-kit"), 8),
			lineFromProduct(findProduct("filing-cabinet"), 2)
		]
	},
	{
		id: "enq-3",
		number: "Q-2026-0003",
		createdAt: "2026-09-22T08:05:00.000Z",
		status: "new",
		validUntil: "2026-10-06T00:00:00.000Z",
		internalNote: "",
		buyer: {
			org: "False Bay Lodge",
			contact: "Mila Jacobs",
			email: "stay@falsebaylodge.co.za",
			phone: "082 441 9022",
			address: "Main Road, Kalk Bay, 7975",
			reference: "LODGE-FURN-26",
			notes: "Four guest rooms to furnish before December. Need beds, wardrobes and a lounge sofa."
		},
		items: [
			lineFromProduct(findProduct("bed-set"), 4),
			lineFromProduct(findProduct("wardrobe-3"), 4),
			lineFromProduct(findProduct("lodge-sofa"), 1)
		]
	}
];
var SEED_INVOICES = [{
	id: "inv-1",
	number: "INV-2026-0001",
	enquiryId: "enq-seed-paid",
	issuedAt: "2026-08-28T10:00:00.000Z",
	dueAt: "2026-09-11T00:00:00.000Z",
	status: "paid",
	buyer: {
		org: "Masiphumelele Community Trust",
		contact: "Nomsa Dlamini",
		email: "ops@mct.org.za",
		phone: "021 785 3340",
		address: "Community Hall, Masiphumelele, Fish Hoek, 7975",
		reference: "MCT-ICT-08",
		notes: ""
	},
	items: [
		lineFromProduct(findProduct("gig-switch"), 2),
		lineFromProduct(findProduct("wifi6-ap"), 4),
		lineFromProduct(findProduct("cat6-drum"), 2)
	]
}];
function sampleState() {
	return {
		basket: [],
		enquiries: SEED_ENQUIRIES,
		invoices: SEED_INVOICES,
		messages: [],
		enquirySeq: 4,
		invoiceSeq: 2,
		messageSeq: 1
	};
}
function lineTotal(item) {
	return item.unitPrice * item.qty;
}
function itemsTotal(items) {
	return items.reduce((sum, item) => sum + lineTotal(item), 0);
}
var useBusinessStore = create()(persist((set, get) => ({
	hydrated: false,
	...sampleState(),
	markHydrated: () => set({ hydrated: true }),
	addToBasket: (product, qty) => {
		const addQty = Math.max(qty ?? product.minQty, product.minQty);
		set((state) => {
			if (state.basket.find((i) => i.productId === product.id)) return { basket: state.basket.map((i) => i.productId === product.id ? {
				...i,
				qty: i.qty + addQty
			} : i) };
			return { basket: [...state.basket, lineFromProduct(product, addQty)] };
		});
	},
	setBasketQty: (productId, qty) => {
		const min = PRODUCTS.find((p) => p.id === productId)?.minQty ?? 1;
		set((state) => ({ basket: state.basket.map((i) => i.productId === productId ? {
			...i,
			qty: Math.max(min, qty)
		} : i).filter((i) => i.qty > 0) }));
	},
	removeFromBasket: (productId) => set((state) => ({ basket: state.basket.filter((i) => i.productId !== productId) })),
	clearBasket: () => set({ basket: [] }),
	submitEnquiry: (buyer) => {
		const { basket, enquirySeq } = get();
		const enquiry = {
			id: `enq-${Date.now()}`,
			number: `Q-2026-${pad(enquirySeq)}`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			status: "new",
			buyer,
			items: basket.map((i) => ({ ...i })),
			validUntil: daysFromNow(14),
			internalNote: ""
		};
		set({
			enquiries: [enquiry, ...get().enquiries],
			enquirySeq: enquirySeq + 1,
			basket: []
		});
		return enquiry;
	},
	setEnquiryStatus: (id, status) => set((state) => ({ enquiries: state.enquiries.map((e) => e.id === id ? {
		...e,
		status
	} : e) })),
	setItemPrice: (enquiryId, productId, unitPrice) => set((state) => ({ enquiries: state.enquiries.map((e) => e.id === enquiryId ? {
		...e,
		items: e.items.map((i) => i.productId === productId ? {
			...i,
			unitPrice: Math.max(0, unitPrice)
		} : i)
	} : e) })),
	setItemQty: (enquiryId, productId, qty) => set((state) => ({ enquiries: state.enquiries.map((e) => e.id === enquiryId ? {
		...e,
		items: e.items.map((i) => i.productId === productId ? {
			...i,
			qty: Math.max(1, qty)
		} : i)
	} : e) })),
	setInternalNote: (id, note) => set((state) => ({ enquiries: state.enquiries.map((e) => e.id === id ? {
		...e,
		internalNote: note
	} : e) })),
	issueQuote: (id) => set((state) => ({ enquiries: state.enquiries.map((e) => e.id === id ? {
		...e,
		status: e.status === "new" ? "quoted" : e.status,
		validUntil: daysFromNow(14)
	} : e) })),
	raiseInvoice: (enquiryId) => {
		const enquiry = get().enquiries.find((e) => e.id === enquiryId);
		if (!enquiry) return null;
		const existing = get().invoices.find((i) => i.enquiryId === enquiryId);
		if (existing) return existing;
		const invoice = {
			id: `inv-${Date.now()}`,
			number: `INV-2026-${pad(get().invoiceSeq)}`,
			enquiryId,
			issuedAt: (/* @__PURE__ */ new Date()).toISOString(),
			dueAt: daysFromNow(14),
			status: "issued",
			buyer: enquiry.buyer,
			items: enquiry.items.map((i) => ({ ...i }))
		};
		set({
			invoices: [invoice, ...get().invoices],
			invoiceSeq: get().invoiceSeq + 1,
			enquiries: get().enquiries.map((e) => e.id === enquiryId ? {
				...e,
				status: "invoiced"
			} : e)
		});
		return invoice;
	},
	markInvoicePaid: (id) => set((state) => ({ invoices: state.invoices.map((i) => i.id === id ? {
		...i,
		status: "paid"
	} : i) })),
	addMessage: (input) => {
		const message = {
			...input,
			id: `msg-${Date.now()}`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			read: false
		};
		set({
			messages: [message, ...get().messages],
			messageSeq: get().messageSeq + 1
		});
		return message;
	},
	markMessageRead: (id) => set((state) => ({ messages: state.messages.map((m) => m.id === id ? {
		...m,
		read: true
	} : m) })),
	restoreSample: () => set(sampleState())
}), {
	name: "oj-connect-desk",
	skipHydration: true,
	partialize: (state) => ({
		basket: state.basket,
		enquiries: state.enquiries,
		invoices: state.invoices,
		messages: state.messages,
		enquirySeq: state.enquirySeq,
		invoiceSeq: state.invoiceSeq,
		messageSeq: state.messageSeq
	})
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CbpQT3oa.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 40 40",
		className: cn("size-8", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "40",
				height: "40",
				rx: "10",
				className: "fill-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "20",
				r: "7",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				className: "text-primary-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M22 13.5c4.2 0 7.5 2.9 7.5 6.5s-3.3 6.5-7.5 6.5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round",
				className: "text-primary-fg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M29.5 26.5v3.2c0 1.4-1.2 2.3-2.8 2.3",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round",
				className: "text-primary-fg"
			})
		]
	});
}
function Wordmark({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-2.5 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-lg tracking-tight",
				children: "OJ CONNECT"
			}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-xs uppercase tracking-[0.18em] text-muted",
				children: "Pty Ltd · Fish Hoek"
			})]
		})]
	});
}
var COMPANY = {
	legalName: "OJ CONNECT (PTY) LTD",
	tradingName: "OJ CONNECT",
	shortName: "OJ Connect",
	tagline: "Supply. Connect. Deliver.",
	registrationNumber: "2026/480860/07",
	csdNumber: "MAAA1752850",
	taxNumber: "9237809281",
	vatVendor: false,
	vatNumber: null,
	country: "South Africa",
	province: "Western Cape",
	municipality: "City of Cape Town",
	city: "Fish Hoek",
	suburb: "Masiphumelele",
	postalCode: "7975",
	street1: "2861 Luntu Road",
	street2: "Masiphumelele",
	ward: "64",
	established: "2026",
	registrationDate: "2026-06-18",
	contact: {
		name: "Okuhle Mgoza",
		role: "Bid office",
		email: "mgcizaokuhle@gmail.com",
		phone: "082 304 4483",
		phoneTel: "+27823044483",
		whatsapp: "https://wa.me/27823044483"
	},
	banking: {
		bank: "Capitec Business Bank",
		accountType: "Current account",
		accountHolder: "OJ CONNECT (PTY) LTD",
		branchCode: "450105",
		branchName: "Universal branch code",
		accountNumber: "1055743944"
	},
	compliance: {
		supplierActive: true,
		taxCompliant: true,
		beeStatus: "Active",
		beeCertificate: "B-BBEE Certificate from CIPC",
		beeIssued: "2026-06-18",
		beeExpiry: "2027-06-17",
		beeVerifiedBy: "CIPC",
		restrictedSupplier: false,
		restrictedDirector: false,
		governmentEmployee: false,
		youthDemographics: true,
		genderDemographics: true,
		bankVerified: true
	}
};
COMPANY.street1, COMPANY.street2, `${COMPANY.city}${COMPANY.province}`, COMPANY.postalCode, COMPANY.country;
var NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/catalogue",
		label: "Catalogue"
	},
	{
		to: "/credentials",
		label: "Credentials"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
function SiteShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [open, setOpen] = (0, import_react.useState)(false);
	const basketCount = useBusinessStore((s) => s.basket.reduce((n, i) => n + i.qty, 0));
	const hydrated = useBusinessStore((s) => s.hydrated);
	const markHydrated = useBusinessStore((s) => s.markHydrated);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useBusinessStore.persist.rehydrate()).finally(() => {
			markHydrated();
		});
	}, [markHydrated]);
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-40 border-b border-border/80 bg-bg/85 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:h-[4.25rem] sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "shrink-0",
							"aria-label": "OJ CONNECT home",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { compact: true })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("rounded-lg px-3 py-2 text-sm transition-colors duration-150", pathname === item.to ? "bg-elevated text-fg" : "text-muted hover:text-fg"),
								children: item.label
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/quote",
									className: cn(buttonVariants({
										variant: "secondary",
										size: "sm"
									}), "hidden sm:inline-flex"),
									children: ["Quote", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums text-muted",
										children: hydrated ? basketCount : 0
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/ops",
									className: cn(buttonVariants({
										variant: "primary",
										size: "sm"
									}), "hidden sm:inline-flex"),
									children: "Desk"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "inline-flex size-11 items-center justify-center rounded-lg md:hidden",
									"aria-label": open ? "Close menu" : "Open menu",
									onClick: () => setOpen((v) => !v),
									children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								})
							]
						})
					]
				}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border px-4 py-3 md:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1",
						children: [
							NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: item.to,
								className: cn("rounded-lg px-3 py-3 text-sm", pathname === item.to ? "bg-elevated text-fg" : "text-muted"),
								children: item.label
							}, item.to)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/quote",
								className: "rounded-lg px-3 py-3 text-sm text-fg",
								children: [
									"Quote basket (",
									hydrated ? basketCount : 0,
									")"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/ops",
								className: "rounded-lg px-3 py-3 text-sm text-fg",
								children: "Operations desk"
							})
						]
					})
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "no-print mt-auto border-t border-border",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xs text-sm text-muted",
							children: "CSD-registered private company supplying clothing, ICT, office stock, security and accommodation furniture from Fish Hoek."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
									children: "Registered office"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-fg",
									children: [
										COMPANY.street1,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										COMPANY.street2,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										COMPANY.city,
										", ",
										COMPANY.province,
										" ",
										COMPANY.postalCode
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-muted",
									children: [
										"CIPC ",
										COMPANY.registrationNumber,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"CSD ",
										COMPANY.csdNumber
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium uppercase tracking-[0.14em] text-muted",
									children: "Bid office"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2",
									children: [
										COMPANY.contact.name,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "text-fg underline-offset-4 hover:underline",
											href: `mailto:${COMPANY.contact.email}`,
											children: COMPANY.contact.email
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											className: "text-fg underline-offset-4 hover:underline",
											href: `tel:${COMPANY.contact.phoneTel}`,
											children: COMPANY.contact.phone
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: COMPANY.contact.whatsapp,
										className: buttonVariants({
											variant: "secondary",
											size: "sm"
										}),
										children: "WhatsApp"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/credentials",
										className: buttonVariants({
											variant: "ghost",
											size: "sm"
										}),
										children: "Tender pack"
									})]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-t border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mx-auto flex max-w-6xl flex-wrap justify-between gap-2 px-4 py-4 text-xs text-subtle sm:px-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							COMPANY.legalName,
							" · Est. ",
							COMPANY.established
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Not a registered VAT vendor" })]
					})
				})]
			})
		]
	});
}
function PageFrame({ eyebrow, title, lede, actions, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 sm:py-14",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl stagger-in",
				children: [
					eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: eyebrow
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-3xl tracking-tight sm:text-4xl",
						children: title
					}),
					lede ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: lede
					}) : null
				]
			}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: actions
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pt-8",
			children
		})]
	});
}
function EmptyNote({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-5 py-8 text-center shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-2 max-w-md text-sm text-muted",
				children: body
			}),
			action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex justify-center",
				children: action
			}) : null
		]
	});
}
var styles_default = "/assets/styles-uIglndNr.css";
var APP_NAME = "OJ CONNECT";
var Route$11 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "OJ CONNECT (Pty) Ltd — CSD-registered Cape Town supplier for clothing, ICT, office stock, security and furniture."
			},
			{
				name: "theme-color",
				content: "#0C1412"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en-ZA",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "bottom-center",
				toastOptions: { className: "bg-elevated text-fg border-border" }
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$10 = () => import("./routes-CaZQL0tL.mjs");
var Route$10 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./catalogue-BG72Y1XX.mjs");
var Route$9 = createFileRoute("/catalogue")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./contact-Duih5kAF.mjs");
var Route$8 = createFileRoute("/contact")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./credentials-Dx6oHxAL.mjs");
var Route$7 = createFileRoute("/credentials")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./ops-BYpSyMOG.mjs");
var Route$6 = createFileRoute("/ops")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./quote-B-7RRyeB.mjs");
var Route$5 = createFileRoute("/quote")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./catalogue.index-CpYZGy6-.mjs");
var searchSchema = object({ family: _enum([
	"clothing",
	"footwear",
	"network",
	"office",
	"security",
	"furniture"
]).optional() });
var Route$4 = createFileRoute("/catalogue/")({
	validateSearch: searchSchema,
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./catalogue._slug-O5D52kNb.mjs");
var Route$3 = createFileRoute("/catalogue/$slug")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./ops.index-Dg7GHh69.mjs");
var Route$2 = createFileRoute("/ops/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./ops.invoices._id-SVK8v4oK.mjs");
var Route$1 = createFileRoute("/ops/invoices/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./ops.quotes._id-DqQVr2_G.mjs");
var Route = createFileRoute("/ops/quotes/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$10.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$11
});
var CatalogueRoute = Route$9.update({
	id: "/catalogue",
	path: "/catalogue",
	getParentRoute: () => Route$11
});
var ContactRoute = Route$8.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$11
});
var CredentialsRoute = Route$7.update({
	id: "/credentials",
	path: "/credentials",
	getParentRoute: () => Route$11
});
var OpsRoute = Route$6.update({
	id: "/ops",
	path: "/ops",
	getParentRoute: () => Route$11
});
var QuoteRoute = Route$5.update({
	id: "/quote",
	path: "/quote",
	getParentRoute: () => Route$11
});
var CatalogueIndexRoute = Route$4.update({
	id: "/",
	path: "/",
	getParentRoute: () => CatalogueRoute
});
var CatalogueSlugRoute = Route$3.update({
	id: "/$slug",
	path: "/$slug",
	getParentRoute: () => CatalogueRoute
});
var OpsIndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => OpsRoute
});
var OpsInvoicesIdRoute = Route$1.update({
	id: "/invoices/$id",
	path: "/invoices/$id",
	getParentRoute: () => OpsRoute
});
var OpsQuotesIdRoute = Route.update({
	id: "/quotes/$id",
	path: "/quotes/$id",
	getParentRoute: () => OpsRoute
});
var CatalogueRouteChildren = {
	CatalogueSlugRoute,
	CatalogueIndexRoute
};
var CatalogueRouteWithChildren = CatalogueRoute._addFileChildren(CatalogueRouteChildren);
var OpsRouteChildren = {
	OpsIndexRoute,
	OpsInvoicesIdRoute,
	OpsQuotesIdRoute
};
var rootRouteChildren = {
	IndexRoute,
	CatalogueRoute: CatalogueRouteWithChildren,
	ContactRoute,
	CredentialsRoute,
	OpsRoute: OpsRoute._addFileChildren(OpsRouteChildren),
	QuoteRoute
};
var routeTree = Route$11._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { zar as C, useBusinessStore as S, formatDateLong as _, Route$4 as a, itemsTotal as b, COMPANY as c, CATEGORIES as d, PRODUCTS as f, formatDate as g, featuredProducts as h, Route$3 as i, Mark as l, cn as m, Route as n, EmptyNote as o, buttonVariants as p, Route$1 as r, PageFrame as s, router_exports as t, Button as u, getCategory as v, leadLabel as x, getProduct as y };
