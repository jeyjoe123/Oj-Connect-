import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as zar, _ as formatDateLong, b as itemsTotal, c as COMPANY, l as Mark } from "./router-CbpQT3oa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-CBJMs9UB.js
var import_jsx_runtime = require_jsx_runtime();
function DocHead({ title, number, date }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-start justify-between gap-4 border-b border-ink/15 pb-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 text-ink",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xl tracking-tight",
				children: COMPANY.tradingName
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-ink/60",
				children: COMPANY.legalName
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-right",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-ink/50",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-2xl tracking-tight text-ink",
					children: number
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ink/60",
					children: date
				})
			]
		})]
	});
}
function Parties({ buyer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-6 sm:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-ink/45",
				children: "From"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-ink",
				children: [
					COMPANY.legalName,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					COMPANY.street1,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					COMPANY.street2,
					", ",
					COMPANY.city,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					COMPANY.province,
					" ",
					COMPANY.postalCode
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-ink/60",
				children: [
					"CIPC ",
					COMPANY.registrationNumber,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"CSD ",
					COMPANY.csdNumber,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					"Income tax ",
					COMPANY.taxNumber
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-ink/45",
				children: "To"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-ink",
				children: [
					buyer.org,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					buyer.contact,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					buyer.email,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
					buyer.phone
				]
			}),
			buyer.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-ink/60",
				children: buyer.address
			}) : null,
			buyer.reference ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-ink/60",
				children: ["Your reference: ", buyer.reference]
			}) : null
		] })]
	});
}
function Lines({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "mt-8 w-full text-left text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-b border-ink/15 text-xs uppercase tracking-[0.12em] text-ink/45",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 pr-3 font-medium",
					children: "Item"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 pr-3 font-medium",
					children: "Qty"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 pr-3 text-right font-medium",
					children: "Unit"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 text-right font-medium",
					children: "Amount"
				})
			]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-b border-ink/8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "py-2.5 pr-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ink",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-xs text-ink/45",
						children: item.sku
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "py-2.5 pr-3 tabular-nums text-ink",
					children: [
						item.qty,
						" ",
						item.unit
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "py-2.5 pr-3 text-right tabular-nums text-ink",
					children: zar(item.unitPrice)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "py-2.5 text-right tabular-nums text-ink",
					children: zar(item.unitPrice * item.qty)
				})
			]
		}, item.productId)) })]
	});
}
function Totals({ items }) {
	const total = itemsTotal(items);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 ml-auto w-full max-w-xs text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between text-ink/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: zar(total)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex justify-between text-ink/60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Not a VAT vendor" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex justify-between border-t border-ink/15 pt-3 font-medium text-ink",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total due (ZAR)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: zar(total)
				})]
			})
		]
	});
}
function QuoteDocument({ enquiry }) {
	const issued = enquiry.status === "new" ? "Enquiry acknowledgement" : "Quotation";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "print-sheet rounded-xl bg-paper p-6 text-ink shadow-[var(--shadow-paper)] sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocHead, {
				title: issued,
				number: enquiry.number,
				date: formatDateLong(enquiry.createdAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parties, { buyer: enquiry.buyer }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lines, { items: enquiry.items }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Totals, { items: enquiry.items }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-xs text-ink/55",
				children: [
					"Valid until ",
					formatDateLong(enquiry.validUntil),
					". Prices are in South African Rand and exclude VAT — ",
					COMPANY.legalName,
					" is not a registered VAT vendor. Lead times confirmed on award."
				]
			}),
			enquiry.buyer.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-ink/55",
				children: ["Buyer note: ", enquiry.buyer.notes]
			}) : null
		]
	});
}
function InvoiceDocument({ invoice }) {
	const b = COMPANY.banking;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "print-sheet rounded-xl bg-paper p-6 text-ink shadow-[var(--shadow-paper)] sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocHead, {
				title: "Tax invoice",
				number: invoice.number,
				date: formatDateLong(invoice.issuedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Parties, { buyer: invoice.buyer }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-ink/55",
				children: [
					"Due ",
					formatDateLong(invoice.dueAt),
					" · Status ",
					invoice.status === "paid" ? "Paid" : "Issued"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lines, { items: invoice.items }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Totals, { items: invoice.items }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-lg bg-cream/60 p-4 text-sm text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.14em] text-ink/45",
						children: "Payment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2",
						children: [
							b.accountHolder,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							b.bank,
							" · ",
							b.accountType,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"Account ",
							b.accountNumber,
							" · Branch ",
							b.branchCode
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-xs text-ink/55",
						children: [
							"Use ",
							invoice.number,
							" as the payment reference. ",
							COMPANY.legalName,
							" is not a registered VAT vendor — no VAT is charged or claimed on this invoice."
						]
					})
				]
			})
		]
	});
}
//#endregion
export { QuoteDocument as n, InvoiceDocument as t };
