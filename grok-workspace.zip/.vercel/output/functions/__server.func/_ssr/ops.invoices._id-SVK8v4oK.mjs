import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Printer } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as zar, S as useBusinessStore, b as itemsTotal, o as EmptyNote, p as buttonVariants, r as Route$1, s as PageFrame, u as Button } from "./router-CbpQT3oa.mjs";
import { t as InvoiceBadge } from "./status-badge-8Oew9vU6.mjs";
import { t as InvoiceDocument } from "./documents-CBJMs9UB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ops.invoices._id-SVK8v4oK.js
var import_jsx_runtime = require_jsx_runtime();
function InvoiceDeskPage() {
	const { id } = Route$1.useParams();
	const invoice = useBusinessStore((s) => s.invoices.find((i) => i.id === id));
	const markInvoicePaid = useBusinessStore((s) => s.markInvoicePaid);
	if (!useBusinessStore((s) => s.hydrated)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Invoice",
		title: "Loading.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Opening file…"
		})
	});
	if (!invoice) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: "Invoice",
		title: "Not on the desk.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyNote, {
			title: "No such invoice",
			body: "Raise one from a quotation on the operations desk.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/ops",
				className: buttonVariants(),
				children: "Back to desk"
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageFrame, {
		eyebrow: invoice.number,
		title: invoice.buyer.org,
		lede: `Total ${zar(itemsTotal(invoice.items))} · due on issue plus 14 days`,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceBadge, { status: invoice.status }),
			invoice.status !== "paid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => {
					markInvoicePaid(invoice.id);
					toast.success(`${invoice.number} marked paid.`);
				},
				children: "Mark paid"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "secondary",
				onClick: () => window.print(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Print"]
			})
		] }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceDocument, { invoice })
	});
}
//#endregion
export { InvoiceDeskPage as component };
