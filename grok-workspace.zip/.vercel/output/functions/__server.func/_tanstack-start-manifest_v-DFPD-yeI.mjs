//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DFPD-yeI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/catalogue",
			"/contact",
			"/credentials",
			"/ops",
			"/quote"
		],
		preloads: [
			"/assets/index-Cr6ww4ht.js",
			"/assets/useStore-Bwb3bsWW.js",
			"/assets/store-DurdVW3a.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/matchContext-DTZFKhir.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cr6ww4ht.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BiIttnUT.js",
			"/assets/product-card-C1p4wUyV.js",
			"/assets/badge-D2Rw-Ieu.js"
		]
	},
	"/catalogue": {
		filePath: "/workspace/src/routes/catalogue.tsx",
		children: ["/catalogue/$slug", "/catalogue/"],
		preloads: ["/assets/catalogue-CbV5321T.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-3j_rtuN4.js", "/assets/input-BjQfXSJ0.js"]
	},
	"/credentials": {
		filePath: "/workspace/src/routes/credentials.tsx",
		children: void 0,
		preloads: ["/assets/credentials-DXmIRWD2.js", "/assets/printer-CLg4fGFN.js"]
	},
	"/ops": {
		filePath: "/workspace/src/routes/ops.tsx",
		children: [
			"/ops/",
			"/ops/invoices/$id",
			"/ops/quotes/$id"
		],
		preloads: ["/assets/ops-CbV5321T.js"]
	},
	"/quote": {
		filePath: "/workspace/src/routes/quote.tsx",
		children: void 0,
		preloads: ["/assets/quote-BPkETYv_.js", "/assets/input-BjQfXSJ0.js"]
	},
	"/catalogue/$slug": {
		filePath: "/workspace/src/routes/catalogue.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/catalogue._slug-HQScsz9Q.js",
			"/assets/product-card-C1p4wUyV.js",
			"/assets/input-BjQfXSJ0.js"
		]
	},
	"/catalogue/": {
		filePath: "/workspace/src/routes/catalogue.index.tsx",
		children: void 0,
		preloads: [
			"/assets/catalogue.index-CFVuPrTl.js",
			"/assets/product-card-C1p4wUyV.js",
			"/assets/input-BjQfXSJ0.js"
		]
	},
	"/ops/": {
		filePath: "/workspace/src/routes/ops.index.tsx",
		children: void 0,
		preloads: ["/assets/ops.index-Cm2g8UHv.js", "/assets/status-badge-CDzTouBf.js"]
	},
	"/ops/invoices/$id": {
		filePath: "/workspace/src/routes/ops.invoices.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/ops.invoices._id-bQ9dSt1E.js",
			"/assets/printer-CLg4fGFN.js",
			"/assets/status-badge-CDzTouBf.js",
			"/assets/documents-D_qEQqbq.js"
		]
	},
	"/ops/quotes/$id": {
		filePath: "/workspace/src/routes/ops.quotes.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/ops.quotes._id-AV8MwOkC.js",
			"/assets/printer-CLg4fGFN.js",
			"/assets/input-BjQfXSJ0.js",
			"/assets/status-badge-CDzTouBf.js",
			"/assets/documents-D_qEQqbq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
