import { createFileRoute, Link } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import { InvoiceDocument } from "@/components/documents";
import { EmptyNote, PageFrame } from "@/components/site-shell";
import { InvoiceBadge } from "@/components/status-badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { zar } from "@/lib/format";
import { itemsTotal, useBusinessStore } from "@/lib/store";

export const Route = createFileRoute("/ops/invoices/$id")({ component: InvoiceDeskPage });

function InvoiceDeskPage() {
  const { id } = Route.useParams();
  const invoice = useBusinessStore((s) => s.invoices.find((i) => i.id === id));
  const markInvoicePaid = useBusinessStore((s) => s.markInvoicePaid);
  const hydrated = useBusinessStore((s) => s.hydrated);

  if (!hydrated) {
    return (
      <PageFrame eyebrow="Invoice" title="Loading.">
        <p className="text-muted">Opening file…</p>
      </PageFrame>
    );
  }

  if (!invoice) {
    return (
      <PageFrame eyebrow="Invoice" title="Not on the desk.">
        <EmptyNote
          title="No such invoice"
          body="Raise one from a quotation on the operations desk."
          action={
            <Link to="/ops" className={buttonVariants()}>
              Back to desk
            </Link>
          }
        />
      </PageFrame>
    );
  }

  return (
    <PageFrame
      eyebrow={invoice.number}
      title={invoice.buyer.org}
      lede={`Total ${zar(itemsTotal(invoice.items))} · due on issue plus 14 days`}
      actions={
        <>
          <InvoiceBadge status={invoice.status} />
          {invoice.status !== "paid" ? (
            <Button
              onClick={() => {
                markInvoicePaid(invoice.id);
                toast.success(`${invoice.number} marked paid.`);
              }}
            >
              Mark paid
            </Button>
          ) : null}
          <Button variant="secondary" onClick={() => window.print()}>
            <Printer className="size-4" />
            Print
          </Button>
        </>
      }
    >
      <InvoiceDocument invoice={invoice} />
    </PageFrame>
  );
}
