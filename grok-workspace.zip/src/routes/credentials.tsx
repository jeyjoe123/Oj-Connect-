import { createFileRoute } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import type { ReactNode } from "react";
import { Mark } from "@/components/logo";
import { PageFrame } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { CATEGORIES } from "@/lib/catalogue";
import { COMPANY } from "@/lib/company";
import { formatDateLong } from "@/lib/format";

export const Route = createFileRoute("/credentials")({ component: CredentialsPage });

function CredentialsPage() {
  const c = COMPANY.compliance;
  return (
    <PageFrame
      eyebrow="Tender pack"
      title="Credentials pulled from the CSD registration."
      lede="Share this page with a bid office. Figures match the Central Supplier Database summary generated 23 September 2026."
      actions={
        <Button variant="secondary" onClick={() => window.print()}>
          <Printer className="size-4" />
          Print pack
        </Button>
      }
    >
      <article className="print-sheet rounded-xl bg-paper p-6 text-ink shadow-[var(--shadow-paper)] sm:p-10">
        <header className="flex items-start justify-between gap-4 border-b border-ink/15 pb-5">
          <div className="flex items-center gap-3">
            <Mark className="size-10" />
            <div>
              <p className="font-display text-2xl tracking-tight">{COMPANY.legalName}</p>
              <p className="text-sm text-ink/60">CSD registration summary for organs of state</p>
            </div>
          </div>
          <p className="text-right text-xs text-ink/50">
            Pack dated
            <br />
            {formatDateLong(new Date().toISOString())}
          </p>
        </header>

        <Section title="Supplier identification">
          <Grid
            rows={[
              ["Legal name", COMPANY.legalName],
              ["Supplier type", "CIPC company · Private company (Pty) Ltd"],
              ["CIPC number", COMPANY.registrationNumber],
              ["CSD number", COMPANY.csdNumber],
              ["Registration date", formatDateLong(COMPANY.registrationDate)],
              ["Business status", "In business"],
              ["Country of origin", COMPANY.country],
              ["Supplier active", c.supplierActive ? "Yes" : "No"],
              ["Restricted supplier", c.restrictedSupplier ? "Yes" : "No"],
              ["Restricted director", c.restrictedDirector ? "Yes" : "No"],
              ["Government employee", c.governmentEmployee ? "Yes" : "No"],
            ]}
          />
        </Section>

        <Section title="Preferred contact">
          <Grid
            rows={[
              ["Contact type", "Bid office"],
              ["Name", COMPANY.contact.name],
              ["Email", COMPANY.contact.email],
              ["Cellphone", COMPANY.contact.phone],
            ]}
          />
        </Section>

        <Section title="Preferred address">
          <Grid
            rows={[
              ["Address type", "Physical"],
              ["Street", COMPANY.street1],
              ["Suburb", COMPANY.street2],
              ["City", COMPANY.city],
              ["Municipality", COMPANY.municipality],
              ["Province", COMPANY.province],
              ["Postal code", COMPANY.postalCode],
              ["Ward", COMPANY.ward],
            ]}
          />
        </Section>

        <Section title="Tax">
          <Grid
            rows={[
              ["Overall tax status", c.taxCompliant ? "Tax compliant" : "Not compliant"],
              ["Registered with SARS", "Yes"],
              ["Income tax number", COMPANY.taxNumber],
              ["VAT vendor", COMPANY.vatVendor ? "Yes" : "No"],
              ["Tax compliance PIN provided", "Yes"],
            ]}
          />
        </Section>

        <Section title="B-BBEE">
          <Grid
            rows={[
              ["Certificate type", c.beeCertificate],
              ["Status", c.beeStatus],
              ["Issue date", formatDateLong(c.beeIssued)],
              ["Expiry date", formatDateLong(c.beeExpiry)],
              ["Verification", c.beeVerifiedBy],
            ]}
          />
        </Section>

        <Section title="Demographics">
          <Grid
            rows={[
              ["Gender demographics", c.genderDemographics ? "Available" : "Not available"],
              ["Youth demographics", c.youthDemographics ? "Available" : "Not available"],
              ["Military veteran", "Not available"],
              ["Disabilities", "Not available"],
            ]}
          />
        </Section>

        <Section title="Commodity families on CSD">
          <ul className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
            {CATEGORIES.map((cat) => (
              <li key={cat.id} className="rounded-md bg-cream/70 px-3 py-2">
                {cat.csdFamily}
              </li>
            ))}
          </ul>
        </Section>

        <p className="mt-8 text-xs text-ink/50">
          Bank verification on CSD succeeded for a Capitec Business current account. Account numbers are
          issued on invoices, not on this public pack. The CSD does not automatically verify foreign
          registration numbers, B-BBEE or demographic information — organs of state verify against the
          applicable institutions.
        </p>
      </article>
    </PageFrame>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-8">
      <h2 className="text-xs font-medium uppercase tracking-[0.16em] text-ink/45">{title}</h2>
      {children}
    </section>
  );
}

function Grid({ rows }: { rows: [string, string][] }) {
  return (
    <dl className="mt-3 grid gap-x-6 gap-y-2 sm:grid-cols-2">
      {rows.map(([k, v]) => (
        <div key={k} className="flex justify-between gap-4 border-b border-ink/10 py-2 text-sm">
          <dt className="text-ink/55">{k}</dt>
          <dd className="text-right tabular-nums">{v}</dd>
        </div>
      ))}
    </dl>
  );
}
