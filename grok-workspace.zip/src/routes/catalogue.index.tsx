import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import { ProductCard } from "@/components/product-card";
import { PageFrame } from "@/components/site-shell";
import { Input } from "@/components/ui/input";
import { CATEGORIES, PRODUCTS, type CategoryId } from "@/lib/catalogue";
import { cn } from "@/lib/utils";

const searchSchema = z.object({
  family: z
    .enum(["clothing", "footwear", "network", "office", "security", "furniture"])
    .optional(),
});

export const Route = createFileRoute("/catalogue/")({
  validateSearch: searchSchema,
  component: CataloguePage,
});

function CataloguePage() {
  const { family } = Route.useSearch();
  const [q, setQ] = useState("");
  const active = family as CategoryId | undefined;

  const items = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return PRODUCTS.filter((p) => {
      if (active && p.category !== active) return false;
      if (!needle) return true;
      return (
        p.name.toLowerCase().includes(needle) ||
        p.sku.toLowerCase().includes(needle) ||
        p.summary.toLowerCase().includes(needle)
      );
    });
  }, [active, q]);

  return (
    <PageFrame
      eyebrow="Catalogue"
      title="Stock specified for public and private buyers."
      lede="Prices are in rand, exclusive of VAT. Minimum order quantities apply. Add lines to a quote and send it from the basket."
    >
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2">
          <FamilyChip to="/catalogue" search={{ family: undefined }} active={!active} label="All families" />
          {CATEGORIES.map((cat) => (
            <FamilyChip
              key={cat.id}
              to="/catalogue"
              search={{ family: cat.id }}
              active={active === cat.id}
              label={cat.label}
            />
          ))}
        </div>
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name or SKU"
          className="lg:max-w-xs"
          aria-label="Search catalogue"
        />
      </div>
      <p className="mt-6 text-sm text-muted">
        {items.length} SKU{items.length === 1 ? "" : "s"}
        {active ? ` in ${CATEGORIES.find((c) => c.id === active)?.label}` : ""}
      </p>
      {items.length === 0 ? (
        <p className="mt-8 text-muted">No stock matches that search.</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </PageFrame>
  );
}

function FamilyChip({
  to,
  search,
  active,
  label,
}: {
  to: "/catalogue";
  search: { family?: CategoryId };
  active: boolean;
  label: string;
}) {
  return (
    <Link
      to={to}
      search={search}
      className={cn(
        "inline-flex h-11 items-center rounded-full px-4 text-sm transition-colors duration-150",
        active ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)] hover:text-fg",
      )}
    >
      {label}
    </Link>
  );
}
