import { createFileRoute } from "@tanstack/react-router";
import { type FormEvent, useState } from "react";
import { toast } from "sonner";
import { PageFrame } from "@/components/site-shell";
import { Button, buttonVariants } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { COMPANY } from "@/lib/company";
import { useBusinessStore } from "@/lib/store";

export const Route = createFileRoute("/contact")({ component: ContactPage });

function ContactPage() {
  const addMessage = useBusinessStore((s) => s.addMessage);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    body: "",
  });
  const [sent, setSent] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.body.trim()) {
      toast.error("Name, email and a message are required.");
      return;
    }
    addMessage(form);
    setSent(true);
    toast.success("Message received on the desk.");
  }

  return (
    <PageFrame
      eyebrow="Bid office"
      title="Talk to the desk."
      lede={`${COMPANY.contact.name} handles quotations from Fish Hoek. Same-day response on working days.`}
    >
      <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
        <aside className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
          <p className="text-xs uppercase tracking-[0.14em] text-muted">Direct</p>
          <p className="mt-3 font-display text-2xl">{COMPANY.contact.name}</p>
          <p className="text-sm text-muted">{COMPANY.contact.role}</p>
          <dl className="mt-6 grid gap-3 text-sm">
            <div>
              <dt className="text-muted">Email</dt>
              <dd>
                <a className="underline-offset-4 hover:underline" href={`mailto:${COMPANY.contact.email}`}>
                  {COMPANY.contact.email}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-muted">Phone</dt>
              <dd>
                <a className="underline-offset-4 hover:underline" href={`tel:${COMPANY.contact.phoneTel}`}>
                  {COMPANY.contact.phone}
                </a>
              </dd>
            </div>
            <div>
              <dt className="text-muted">Office</dt>
              <dd>
                {COMPANY.street1}, {COMPANY.street2}
                <br />
                {COMPANY.city}, {COMPANY.postalCode}
              </dd>
            </div>
          </dl>
          <a href={COMPANY.contact.whatsapp} className={`${buttonVariants({ variant: "secondary" })} mt-6`}>
            WhatsApp
          </a>
        </aside>

        {sent ? (
          <div className="rounded-xl bg-surface p-8 text-center shadow-[var(--shadow-border)]">
            <p className="font-display text-2xl">Received.</p>
            <p className="mt-2 text-sm text-muted">
              It is logged on the operations desk. For urgent RFQs, WhatsApp or call {COMPANY.contact.phone}.
            </p>
            <Button className="mt-6" variant="ghost" onClick={() => setSent(false)}>
              Send another
            </Button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="grid gap-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Name">
                <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </Field>
              <Field label="Email">
                <Input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Phone">
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </Field>
              <Field label="Subject">
                <Input
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  placeholder="RFQ, account, delivery"
                />
              </Field>
            </div>
            <Field label="Message">
              <Textarea
                required
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="What do you need supplied, and by when?"
              />
            </Field>
            <Button type="submit" size="lg">
              Send to the desk
            </Button>
          </form>
        )}
      </div>
    </PageFrame>
  );
}
