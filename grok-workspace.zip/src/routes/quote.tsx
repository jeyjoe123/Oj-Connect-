import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { type FormEvent, useState } from "react";
import { toast } from "sonner";
import { EmptyNote, PageFrame } from "@/components/site-shell";
import { Button, buttonVariants } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/input";
import { zar } from "@/lib/format";
import { itemsTotal, useBusinessStore } from "@/lib/store";

export const Route = createFileRoute("/quote")({ component: QuotePage });

function QuotePage() {
  const navigate = useNavigate();
  const basket = useBusinessStore((s) => s.basket);
  const setBasketQty = useBusinessStore((s) => s.setBasketQty);
  const removeFromBasket = useBusinessStore((s) => s.removeFromBasket);
  const clearBasket = useBusinessStore((s) => s.clearBasket);
  const submitEnquiry = useBusinessStore((s) => s.submitEnquiry);
  const hydrated = useBusinessStore((s) => s.hydrated);

  const [buyer, setBuyer] = useState({
    org: "",
    contact: "",
    email: "",
    phone: "",
    address: "",
    reference: "",
    notes: "",
  });

  const total = itemsTotal(basket);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!basket.length) return;
    if (!buyer.org.trim() || !buyer.contact.trim() || !buyer.email.trim()) {
      toast.error("Organisation, contact name and email are required.");
      return;
    }
    const enquiry = submitEnquiry(buyer);
    toast.success(`${enquiry.number} is on the desk.`);
    void navigate({ to: "/ops/quotes/$id", params: { id: enquiry.id } });
  }

  if (!hydrated) {
    return (
      <PageFrame eyebrow="Quote basket" title="Building your RFQ.">
        <p className="text-muted">Loading basket…</p>
      </PageFrame>
    );
  }

  if (!basket.length) {
    return (
      <PageFrame eyebrow="Quote basket" title="No lines yet.">
        <EmptyNote
          title="The basket is empty"
          body="Add SKUs from the catalogue. Minimum order quantities are applied automatically."
          action={
            <Link to="/catalogue" className={buttonVariants()}>
              Browse catalogue
            </Link>
          }
        />
      </PageFrame>
    );
  }

  return (
    <PageFrame
      eyebrow="Quote basket"
      title="Request a quotation."
      lede="This becomes a numbered enquiry on the OJ CONNECT desk. A 14-day validity is applied when the quote is issued."
      actions={
        <Button variant="ghost" onClick={clearBasket}>
          Clear basket
        </Button>
      }
    >
      <form onSubmit={onSubmit} className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <ul className="grid gap-3">
            {basket.map((item) => (
              <li
                key={item.productId}
                className="flex flex-col gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:flex-row sm:items-center"
              >
                <div className="flex-1">
                  <p className="font-medium">{item.name}</p>
                  <p className="text-xs text-muted">
                    {item.sku} · {zar(item.unitPrice)} / {item.unit}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min={1}
                    className="w-24"
                    value={item.qty}
                    onChange={(e) => setBasketQty(item.productId, Number(e.target.value) || 1)}
                    aria-label={`Quantity for ${item.name}`}
                  />
                  <p className="w-24 text-right tabular-nums">{zar(item.unitPrice * item.qty)}</p>
                  <Button variant="ghost" size="sm" onClick={() => removeFromBasket(item.productId)}>
                    Remove
                  </Button>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex items-center justify-between border-t border-border pt-4">
            <p className="text-sm text-muted">Estimated total (no VAT)</p>
            <p className="font-display text-2xl tabular-nums">{zar(total)}</p>
          </div>
        </div>

        <div className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
          <p className="font-display text-xl">Buyer details</p>
          <div className="mt-5 grid gap-4">
            <Field label="Organisation">
              <Input
                required
                value={buyer.org}
                onChange={(e) => setBuyer({ ...buyer, org: e.target.value })}
                placeholder="Department, school or company"
              />
            </Field>
            <Field label="Contact name">
              <Input
                required
                value={buyer.contact}
                onChange={(e) => setBuyer({ ...buyer, contact: e.target.value })}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Email">
                <Input
                  required
                  type="email"
                  value={buyer.email}
                  onChange={(e) => setBuyer({ ...buyer, email: e.target.value })}
                />
              </Field>
              <Field label="Phone">
                <Input value={buyer.phone} onChange={(e) => setBuyer({ ...buyer, phone: e.target.value })} />
              </Field>
            </div>
            <Field label="Delivery address">
              <Input value={buyer.address} onChange={(e) => setBuyer({ ...buyer, address: e.target.value })} />
            </Field>
            <Field label="Your RFQ / order reference">
              <Input
                value={buyer.reference}
                onChange={(e) => setBuyer({ ...buyer, reference: e.target.value })}
                placeholder="RFQ-…"
              />
            </Field>
            <Field label="Notes">
              <Textarea
                value={buyer.notes}
                onChange={(e) => setBuyer({ ...buyer, notes: e.target.value })}
                placeholder="Sizes, colours, site access, delivery window"
              />
            </Field>
            <Button type="submit" size="lg">
              Submit RFQ
            </Button>
          </div>
        </div>
      </form>
    </PageFrame>
  );
}
