import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BadgeCheck, Building2, FileCheck2, Landmark, ShieldCheck } from "lucide-react";
import { ProductCard } from "@/components/product-card";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { CATEGORIES, featuredProducts } from "@/lib/catalogue";
import { COMPANY } from "@/lib/company";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const STEPS = [
  { n: "01", title: "Specify", body: "Browse the six CSD commodity families and add SKUs to a quote basket." },
  { n: "02", title: "Request", body: "Send an RFQ with your organ of state or company details. It lands on the desk the same day." },
  { n: "03", title: "Award", body: "We return a dated quotation. On award we raise a South African invoice — no VAT loaded." },
  { n: "04", title: "Deliver", body: "Stock ships from Fish Hoek across the City of Cape Town and the Western Cape." },
];

function Home() {
  return (
    <div>
      <section className="relative overflow-hidden border-b border-border">
        <div className="grid-fade pointer-events-none absolute inset-0" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:px-6 sm:py-20 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
          <div className="stagger-in max-w-xl">
            <div className="flex flex-wrap gap-2">
              <Badge tone="live">CSD active</Badge>
              <Badge>Tax compliant</Badge>
              <Badge>B-BBEE active</Badge>
            </div>
            <p className="mt-6 text-xs font-medium uppercase tracking-[0.2em] text-muted">
              Fish Hoek · City of Cape Town · Est. {COMPANY.established}
            </p>
            <h1 className="mt-3 font-display text-4xl leading-none tracking-tight sm:text-6xl">
              The supply desk for a working Cape Town company.
            </h1>
            <p className="mt-5 max-w-md text-base text-muted sm:text-lg">
              {COMPANY.legalName} is on the Central Supplier Database. This is the live storefront —
              catalogue, RFQ, quotation and invoice — built around the CSD registration.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/catalogue" className={buttonVariants({ size: "lg" })}>
                Open catalogue
                <ArrowRight className="size-4" />
              </Link>
              <Link to="/credentials" className={buttonVariants({ variant: "secondary", size: "lg" })}>
                Tender credentials
              </Link>
            </div>
          </div>
          <aside className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] sm:p-6">
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Supplier file</p>
            <dl className="mt-4 grid gap-3 text-sm">
              <Row k="Legal name" v={COMPANY.legalName} />
              <Row k="CIPC" v={COMPANY.registrationNumber} />
              <Row k="CSD number" v={COMPANY.csdNumber} />
              <Row k="Income tax" v={COMPANY.taxNumber} />
              <Row k="VAT" v="Not a registered vendor" />
              <Row k="Bid office" v={COMPANY.contact.name} />
            </dl>
            <Link
              to="/ops"
              className="mt-5 flex items-center justify-between rounded-lg bg-elevated px-3 py-3 text-sm"
            >
              Open operations desk
              <ArrowRight className="size-4 text-muted" />
            </Link>
          </aside>
        </div>
      </section>

      <section className="border-b border-border">
        <div className="mx-auto grid max-w-6xl gap-px bg-border sm:grid-cols-4">
          <Stat icon={ShieldCheck} label="CSD supplier" value={COMPANY.csdNumber} />
          <Stat icon={Landmark} label="CIPC company" value={COMPANY.registrationNumber} />
          <Stat icon={FileCheck2} label="Tax status" value="SARS compliant" />
          <Stat icon={BadgeCheck} label="B-BBEE" value="CIPC verified · Active" />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">CSD families</p>
            <h2 className="mt-2 font-display text-3xl tracking-tight">What we supply</h2>
          </div>
          <Link to="/catalogue" className={cn(buttonVariants({ variant: "ghost", size: "sm" }), "hidden sm:inline-flex")}>
            All SKUs
          </Link>
        </div>
        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              to="/catalogue"
              search={{ family: cat.id }}
              className="group rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
            >
              <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{cat.csdFamily}</p>
              <p className="mt-3 font-display text-2xl tracking-tight group-hover:text-primary">{cat.label}</p>
              <p className="mt-2 text-sm text-muted">{cat.blurb}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-surface/40">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16">
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">How the desk works</p>
          <h2 className="mt-2 font-display text-3xl tracking-tight">From RFQ to invoice</h2>
          <ol className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map((step) => (
              <li key={step.n}>
                <p className="font-display text-2xl text-primary">{step.n}</p>
                <p className="mt-2 font-medium">{step.title}</p>
                <p className="mt-1 text-sm text-muted">{step.body}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Standing stock</p>
            <h2 className="mt-2 font-display text-3xl tracking-tight">Featured SKUs</h2>
          </div>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featuredProducts().map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 sm:px-6 md:grid-cols-2">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.16em] text-muted">Registered office</p>
            <h2 className="mt-2 font-display text-3xl tracking-tight">Based in Fish Hoek, serving the peninsula.</h2>
            <p className="mt-4 text-muted">
              Physical address on CSD: {COMPANY.street1}, {COMPANY.street2}, {COMPANY.city}, ward{" "}
              {COMPANY.ward}, {COMPANY.municipality}. Bid office is {COMPANY.contact.name}.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Link to="/contact" className={buttonVariants()}>
                Send an enquiry
              </Link>
              <a href={COMPANY.contact.whatsapp} className={buttonVariants({ variant: "secondary" })}>
                WhatsApp the desk
              </a>
            </div>
          </div>
          <div className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)]">
            <div className="flex items-center gap-2 text-muted">
              <Building2 className="size-4" />
              <span className="text-xs uppercase tracking-[0.14em]">On the map</span>
            </div>
            <div className="relative mt-4 overflow-hidden rounded-lg bg-elevated">
              <svg viewBox="0 0 320 180" className="h-44 w-full text-primary" aria-hidden="true">
                <rect width="320" height="180" className="fill-elevated" />
                <path
                  d="M20 40 C80 20, 140 50, 180 70 S260 90, 300 50"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.2"
                  opacity="0.45"
                />
                <path
                  d="M10 110 C90 90, 150 130, 220 120 S300 150, 320 140"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.2"
                  opacity="0.3"
                />
                <circle cx="214" cy="118" r="7" className="fill-primary" />
                <circle cx="214" cy="118" r="16" fill="none" stroke="currentColor" strokeWidth="1.2" opacity="0.5" />
              </svg>
              <p className="px-4 pb-4 text-sm">
                {COMPANY.street1}
                <br />
                {COMPANY.city}, {COMPANY.postalCode}
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border pb-2">
      <dt className="text-muted">{k}</dt>
      <dd className="text-right tabular-nums">{v}</dd>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof ShieldCheck;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 bg-bg px-4 py-5 sm:px-6">
      <Icon className="mt-0.5 size-4 text-primary" />
      <div>
        <p className="text-xs uppercase tracking-[0.14em] text-muted">{label}</p>
        <p className="mt-1 text-sm tabular-nums">{value}</p>
      </div>
    </div>
  );
}
