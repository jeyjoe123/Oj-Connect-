import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { InvoiceBadge, QuoteBadge } from "@/components/status-badge";
import { EmptyNote, PageFrame } from "@/components/site-shell";
import { Button, buttonVariants } from "@/components/ui/button";
import { formatDate, zar } from "@/lib/format";
import { itemsTotal, useBusinessStore, type QuoteStatus } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/ops/")({ component: OpsPage });

const STATUSES: QuoteStatus[] = ["new", "quoted", "awarded", "invoiced", "closed"];

function OpsPage() {
  const enquiries = useBusinessStore((s) => s.enquiries);
  const invoices = useBusinessStore((s) => s.invoices);
  const messages = useBusinessStore((s) => s.messages);
  const markMessageRead = useBusinessStore((s) => s.markMessageRead);
  const restoreSample = useBusinessStore((s) => s.restoreSample);
  const hydrated = useBusinessStore((s) => s.hydrated);

  const openValue = enquiries
    .filter((e) => e.status === "new" || e.status === "quoted")
    .reduce((n, e) => n + itemsTotal(e.items), 0);
  const awardedValue = enquiries
    .filter((e) => e.status === "awarded" || e.status === "invoiced")
    .reduce((n, e) => n + itemsTotal(e.items), 0);
  const outstanding = invoices
    .filter((i) => i.status === "issued")
    .reduce((n, i) => n + itemsTotal(i.items), 0);
  const unread = messages.filter((m) => !m.read).length;

  const chart = STATUSES.map((status) => ({
    status,
    value: enquiries.filter((e) => e.status === status).reduce((n, e) => n + itemsTotal(e.items), 0),
    count: enquiries.filter((e) => e.status === status).length,
  }));

  if (!hydrated) {
    return (
      <PageFrame eyebrow="Operations desk" title="Opening the books.">
        <p className="text-muted">Loading pipeline…</p>
      </PageFrame>
    );
  }

  return (
    <PageFrame
      eyebrow="Operations desk"
      title="Quotes, invoices, messages."
      lede="This desk is the working copy of OJ CONNECT — RFQs in, quotations out, invoices raised. Sample pipeline is loaded so you can run it immediately."
      actions={
        <Button variant="secondary" onClick={restoreSample}>
          Restore sample pipeline
        </Button>
      }
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi
          label="Open RFQ value"
          value={zar(openValue)}
          hint={`${enquiries.filter((e) => e.status === "new" || e.status === "quoted").length} live`}
        />
        <Kpi label="Awarded / invoiced" value={zar(awardedValue)} hint="Won work" />
        <Kpi
          label="Invoices outstanding"
          value={zar(outstanding)}
          hint={`${invoices.filter((i) => i.status === "issued").length} issued`}
        />
        <Kpi label="Unread messages" value={String(unread)} hint={`${messages.length} total`} />
      </div>

      <div className="mt-8 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
        <p className="text-xs uppercase tracking-[0.14em] text-muted">Pipeline value by status</p>
        <div className="mt-3 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <XAxis
                dataKey="status"
                stroke="var(--color-muted)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="var(--color-muted)"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => (v >= 1000 ? `${Math.round(v / 1000)}k` : String(v))}
              />
              <Tooltip
                cursor={{ fill: "color-mix(in oklab, var(--color-fg) 4%, transparent)" }}
                contentStyle={{
                  background: "var(--color-surface)",
                  border: "1px solid var(--color-border)",
                  borderRadius: 12,
                  color: "var(--color-fg)",
                }}
                formatter={(value) => zar(Number(value ?? 0))}
              />
              <Bar dataKey="value" fill="var(--color-primary)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.2fr_0.8fr]">
        <section>
          <h2 className="font-display text-2xl tracking-tight">Enquiries</h2>
          {enquiries.length === 0 ? (
            <div className="mt-4">
              <EmptyNote
                title="No enquiries"
                body="Submit an RFQ from the catalogue, or restore the sample pipeline."
              />
            </div>
          ) : (
            <ul className="mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]">
              {enquiries.map((e) => (
                <li key={e.id}>
                  <Link
                    to="/ops/quotes/$id"
                    params={{ id: e.id }}
                    className="flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div>
                      <p className="font-medium">{e.buyer.org}</p>
                      <p className="text-xs text-muted">
                        {e.number} · {formatDate(e.createdAt)} · {e.items.length} lines
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="tabular-nums text-sm">{zar(itemsTotal(e.items))}</span>
                      <QuoteBadge status={e.status} />
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <div className="grid gap-8">
          <section>
            <h2 className="font-display text-2xl tracking-tight">Invoices</h2>
            {invoices.length === 0 ? (
              <p className="mt-3 text-sm text-muted">No invoices raised yet.</p>
            ) : (
              <ul className="mt-4 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]">
                {invoices.map((inv) => (
                  <li key={inv.id}>
                    <Link
                      to="/ops/invoices/$id"
                      params={{ id: inv.id }}
                      className="flex items-center justify-between gap-3 px-4 py-4"
                    >
                      <div>
                        <p className="font-medium">{inv.number}</p>
                        <p className="text-xs text-muted">{inv.buyer.org}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="tabular-nums text-sm">{zar(itemsTotal(inv.items))}</span>
                        <InvoiceBadge status={inv.status} />
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section>
            <h2 className="font-display text-2xl tracking-tight">Inbox</h2>
            {messages.length === 0 ? (
              <p className="mt-3 text-sm text-muted">Contact form messages land here.</p>
            ) : (
              <ul className="mt-4 grid gap-3">
                {messages.map((m) => (
                  <li
                    key={m.id}
                    className={cn(
                      "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
                      !m.read && "ring-1 ring-primary/40",
                    )}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-medium">{m.name}</p>
                        <p className="text-xs text-muted">
                          {m.email} · {formatDate(m.createdAt)}
                        </p>
                      </div>
                      {!m.read ? (
                        <Button size="sm" variant="ghost" onClick={() => markMessageRead(m.id)}>
                          Mark read
                        </Button>
                      ) : null}
                    </div>
                    {m.subject ? <p className="mt-2 text-sm">{m.subject}</p> : null}
                    <p className="mt-1 text-sm text-muted">{m.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>

      <p className="mt-10 text-center">
        <Link to="/catalogue" className={buttonVariants({ variant: "secondary" })}>
          Raise a new RFQ from catalogue
        </Link>
      </p>
    </PageFrame>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="text-xs uppercase tracking-[0.14em] text-muted">{label}</p>
      <p className="mt-2 font-display text-2xl tabular-nums tracking-tight">{value}</p>
      <p className="mt-1 text-xs text-subtle">{hint}</p>
    </div>
  );
}
