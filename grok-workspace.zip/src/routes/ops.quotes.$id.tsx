import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Printer } from "lucide-react";
import { toast } from "sonner";
import { QuoteDocument } from "@/components/documents";
import { EmptyNote, PageFrame } from "@/components/site-shell";
import { QuoteBadge } from "@/components/status-badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { zar } from "@/lib/format";
import { itemsTotal, useBusinessStore, type QuoteStatus } from "@/lib/store";

export const Route = createFileRoute("/ops/quotes/$id")({ component: QuoteDeskPage });

const NEXT: { status: QuoteStatus; label: string }[] = [
  { status: "new", label: "New" },
  { status: "quoted", label: "Quoted" },
  { status: "awarded", label: "Awarded" },
  { status: "invoiced", label: "Invoiced" },
  { status: "closed", label: "Closed" },
];

function QuoteDeskPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const enquiry = useBusinessStore((s) => s.enquiries.find((e) => e.id === id));
  const issueQuote = useBusinessStore((s) => s.issueQuote);
  const setEnquiryStatus = useBusinessStore((s) => s.setEnquiryStatus);
  const setItemPrice = useBusinessStore((s) => s.setItemPrice);
  const setItemQty = useBusinessStore((s) => s.setItemQty);
  const setInternalNote = useBusinessStore((s) => s.setInternalNote);
  const raiseInvoice = useBusinessStore((s) => s.raiseInvoice);
  const invoices = useBusinessStore((s) => s.invoices);
  const hydrated = useBusinessStore((s) => s.hydrated);

  if (!hydrated) {
    return (
      <PageFrame eyebrow="Quote" title="Loading.">
        <p className="text-muted">Opening file…</p>
      </PageFrame>
    );
  }

  if (!enquiry) {
    return (
      <PageFrame eyebrow="Quote" title="Not on the desk.">
        <EmptyNote
          title="No such enquiry"
          body="It may have been cleared with the sample restore."
          action={
            <Link to="/ops" className={buttonVariants()}>
              Back to desk
            </Link>
          }
        />
      </PageFrame>
    );
  }

  const linkedInvoice = invoices.find((i) => i.enquiryId === enquiry.id);

  return (
    <PageFrame
      eyebrow={enquiry.number}
      title={enquiry.buyer.org}
      lede={`${enquiry.buyer.contact} · ${enquiry.buyer.email}${enquiry.buyer.reference ? ` · ${enquiry.buyer.reference}` : ""}`}
      actions={
        <>
          <QuoteBadge status={enquiry.status} />
          <Button variant="secondary" onClick={() => window.print()}>
            <Printer className="size-4" />
            Print
          </Button>
        </>
      }
    >
      <div className="no-print mb-8 flex flex-wrap gap-2">
        {NEXT.map((s) => (
          <button
            key={s.status}
            type="button"
            onClick={() => setEnquiryStatus(enquiry.id, s.status)}
            className={`h-10 rounded-full px-4 text-sm ${
              enquiry.status === s.status
                ? "bg-primary text-primary-fg"
                : "bg-surface text-muted shadow-[var(--shadow-border)]"
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      <div className="no-print mb-8 grid gap-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
        {enquiry.items.map((item) => (
          <div key={item.productId} className="grid items-center gap-3 sm:grid-cols-[1fr_5rem_7rem_6rem]">
            <div>
              <p className="text-sm font-medium">{item.name}</p>
              <p className="text-xs text-muted">{item.sku}</p>
            </div>
            <Input
              type="number"
              min={1}
              value={item.qty}
              aria-label={`Qty ${item.name}`}
              onChange={(e) => setItemQty(enquiry.id, item.productId, Number(e.target.value) || 1)}
            />
            <Input
              type="number"
              min={0}
              step="0.01"
              value={item.unitPrice}
              aria-label={`Price ${item.name}`}
              onChange={(e) => setItemPrice(enquiry.id, item.productId, Number(e.target.value) || 0)}
            />
            <p className="text-right text-sm tabular-nums">{zar(item.unitPrice * item.qty)}</p>
          </div>
        ))}
        <p className="text-right font-display text-xl tabular-nums">{zar(itemsTotal(enquiry.items))}</p>
      </div>

      <div className="no-print mb-8 grid gap-4 lg:grid-cols-2">
        <label className="grid gap-2">
          <span className="text-xs uppercase tracking-[0.14em] text-muted">Internal note</span>
          <Textarea
            value={enquiry.internalNote}
            onChange={(e) => setInternalNote(enquiry.id, e.target.value)}
            placeholder="Delivery, award notes, follow-up"
          />
        </label>
        <div className="flex flex-wrap content-end gap-2">
          <Button
            onClick={() => {
              issueQuote(enquiry.id);
              toast.success(`${enquiry.number} issued as a quotation.`);
            }}
          >
            Issue quotation
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              const invoice = raiseInvoice(enquiry.id);
              if (!invoice) return;
              toast.success(`${invoice.number} raised.`);
              void navigate({ to: "/ops/invoices/$id", params: { id: invoice.id } });
            }}
          >
            Raise invoice
          </Button>
          {linkedInvoice ? (
            <Link
              to="/ops/invoices/$id"
              params={{ id: linkedInvoice.id }}
              className={buttonVariants({ variant: "ghost" })}
            >
              Open {linkedInvoice.number}
            </Link>
          ) : null}
        </div>
      </div>

      <QuoteDocument enquiry={enquiry} />
    </PageFrame>
  );
}
