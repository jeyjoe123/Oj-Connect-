import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ProductArt } from "@/components/product-art";
import { ProductCard } from "@/components/product-card";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getCategory, getProduct, PRODUCTS } from "@/lib/catalogue";
import { leadLabel, zar } from "@/lib/format";
import { useBusinessStore } from "@/lib/store";

export const Route = createFileRoute("/catalogue/$slug")({
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const product = getProduct(slug);
  if (!product) throw notFound();
  const category = getCategory(product.category);
  const addToBasket = useBusinessStore((s) => s.addToBasket);
  const [qty, setQty] = useState(product.minQty);
  const related = PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
      <p className="text-sm text-muted">
        <Link to="/catalogue" className="hover:text-fg">
          Catalogue
        </Link>
        <span className="px-2">/</span>
        <Link to="/catalogue" search={{ family: product.category }} className="hover:text-fg">
          {category.label}
        </Link>
      </p>
      <div className="mt-6 grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <ProductArt category={product.category} seed={product.id} className="aspect-[4/3] w-full rounded-xl" />
        <div>
          <p className="text-xs uppercase tracking-[0.14em] text-muted">{product.sku}</p>
          <h1 className="mt-2 font-display text-3xl tracking-tight sm:text-4xl">{product.name}</h1>
          <p className="mt-4 text-muted">{product.description}</p>
          <p className="mt-6 font-display text-4xl tabular-nums tracking-tight">{zar(product.price)}</p>
          <p className="mt-1 text-sm text-muted">
            per {product.unit} · min {product.minQty} · {leadLabel(product.leadDays)}
          </p>
          <div className="mt-6 flex flex-wrap items-end gap-3">
            <label className="grid gap-2">
              <span className="text-xs uppercase tracking-[0.14em] text-muted">Quantity</span>
              <Input
                type="number"
                min={product.minQty}
                value={qty}
                className="w-28"
                onChange={(e) => setQty(Math.max(product.minQty, Number(e.target.value) || product.minQty))}
              />
            </label>
            <Button
              size="lg"
              onClick={() => {
                addToBasket(product, qty);
                toast.success(`Added ${qty} ${product.unit} to quote`);
              }}
            >
              Add to quote
            </Button>
            <Link to="/quote" className={buttonVariants({ variant: "secondary", size: "lg" })}>
              View basket
            </Link>
          </div>
          <dl className="mt-8 grid gap-3 border-t border-border pt-6 text-sm sm:grid-cols-2">
            {product.specs.map((spec) => (
              <div key={spec.label} className="rounded-lg bg-surface px-4 py-3 shadow-[var(--shadow-border)]">
                <dt className="text-xs uppercase tracking-[0.14em] text-muted">{spec.label}</dt>
                <dd className="mt-1">{spec.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
      {related.length ? (
        <div className="mt-16">
          <h2 className="font-display text-2xl tracking-tight">More in {category.label}</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
