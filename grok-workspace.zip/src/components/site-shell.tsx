import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { type ReactNode, useEffect, useState } from "react";
import { Wordmark } from "@/components/logo";
import { Button, buttonVariants } from "@/components/ui/button";
import { COMPANY } from "@/lib/company";
import { useBusinessStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/catalogue", label: "Catalogue" },
  { to: "/credentials", label: "Credentials" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const basketCount = useBusinessStore((s) => s.basket.reduce((n, i) => n + i.qty, 0));
  const hydrated = useBusinessStore((s) => s.hydrated);
  const markHydrated = useBusinessStore((s) => s.markHydrated);

  useEffect(() => {
    void Promise.resolve(useBusinessStore.persist.rehydrate()).finally(() => {
      markHydrated();
    });
  }, [markHydrated]);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="no-print sticky top-0 z-40 border-b border-border/80 bg-bg/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:h-[4.25rem] sm:px-6">
          <Link to="/" className="shrink-0" aria-label="OJ CONNECT home">
            <Wordmark compact />
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm transition-colors duration-150",
                  pathname === item.to ? "bg-elevated text-fg" : "text-muted hover:text-fg",
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <Link
              to="/quote"
              className={cn(buttonVariants({ variant: "secondary", size: "sm" }), "hidden sm:inline-flex")}
            >
              Quote
              <span className="tabular-nums text-muted">{hydrated ? basketCount : 0}</span>
            </Link>
            <Link to="/ops" className={cn(buttonVariants({ variant: "primary", size: "sm" }), "hidden sm:inline-flex")}>
              Desk
            </Link>
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-lg md:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
        {open ? (
          <div className="border-t border-border px-4 py-3 md:hidden">
            <div className="grid gap-1">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "rounded-lg px-3 py-3 text-sm",
                    pathname === item.to ? "bg-elevated text-fg" : "text-muted",
                  )}
                >
                  {item.label}
                </Link>
              ))}
              <Link to="/quote" className="rounded-lg px-3 py-3 text-sm text-fg">
                Quote basket ({hydrated ? basketCount : 0})
              </Link>
              <Link to="/ops" className="rounded-lg px-3 py-3 text-sm text-fg">
                Operations desk
              </Link>
            </div>
          </div>
        ) : null}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="no-print mt-auto border-t border-border">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
          <div>
            <Wordmark />
            <p className="mt-3 max-w-xs text-sm text-muted">
              CSD-registered private company supplying clothing, ICT, office stock, security and
              accommodation furniture from Fish Hoek.
            </p>
          </div>
          <div className="text-sm">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Registered office</p>
            <p className="mt-2 text-fg">
              {COMPANY.street1}
              <br />
              {COMPANY.street2}
              <br />
              {COMPANY.city}, {COMPANY.province} {COMPANY.postalCode}
            </p>
            <p className="mt-3 text-muted">
              CIPC {COMPANY.registrationNumber}
              <br />
              CSD {COMPANY.csdNumber}
            </p>
          </div>
          <div className="text-sm">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-muted">Bid office</p>
            <p className="mt-2">
              {COMPANY.contact.name}
              <br />
              <a className="text-fg underline-offset-4 hover:underline" href={`mailto:${COMPANY.contact.email}`}>
                {COMPANY.contact.email}
              </a>
              <br />
              <a className="text-fg underline-offset-4 hover:underline" href={`tel:${COMPANY.contact.phoneTel}`}>
                {COMPANY.contact.phone}
              </a>
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <a href={COMPANY.contact.whatsapp} className={buttonVariants({ variant: "secondary", size: "sm" })}>
                WhatsApp
              </a>
              <Link to="/credentials" className={buttonVariants({ variant: "ghost", size: "sm" })}>
                Tender pack
              </Link>
            </div>
          </div>
        </div>
        <div className="border-t border-border">
          <p className="mx-auto flex max-w-6xl flex-wrap justify-between gap-2 px-4 py-4 text-xs text-subtle sm:px-6">
            <span>
              {COMPANY.legalName} · Est. {COMPANY.established}
            </span>
            <span>Not a registered VAT vendor</span>
          </p>
        </div>
      </footer>
    </div>
  );
}

export function PageFrame({
  eyebrow,
  title,
  lede,
  actions,
  children,
}: {
  eyebrow?: string;
  title: string;
  lede?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
      <div className="flex flex-col gap-6 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
        <div className="max-w-2xl stagger-in">
          {eyebrow ? (
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted">{eyebrow}</p>
          ) : null}
          <h1 className="mt-2 font-display text-3xl tracking-tight sm:text-4xl">{title}</h1>
          {lede ? <p className="mt-3 text-muted">{lede}</p> : null}
        </div>
        {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
      </div>
      <div className="pt-8">{children}</div>
    </div>
  );
}

export function EmptyNote({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="rounded-xl bg-surface px-5 py-8 text-center shadow-[var(--shadow-border)]">
      <p className="font-display text-xl">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted">{body}</p>
      {action ? <div className="mt-5 flex justify-center">{action}</div> : null}
    </div>
  );
}

export { Button };
