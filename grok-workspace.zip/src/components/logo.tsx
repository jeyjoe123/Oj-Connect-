import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      className={cn("size-8", className)}
      aria-hidden="true"
    >
      <rect width="40" height="40" rx="10" className="fill-primary" />
      <circle cx="16" cy="20" r="7" fill="none" stroke="currentColor" strokeWidth="2.2" className="text-primary-fg" />
      <path
        d="M22 13.5c4.2 0 7.5 2.9 7.5 6.5s-3.3 6.5-7.5 6.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        className="text-primary-fg"
      />
      <path
        d="M29.5 26.5v3.2c0 1.4-1.2 2.3-2.8 2.3"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        className="text-primary-fg"
      />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5 text-fg">
      <Mark />
      <span className="leading-none">
        <span className="font-display text-lg tracking-tight">OJ CONNECT</span>
        {compact ? null : (
          <span className="mt-0.5 block text-xs uppercase tracking-[0.18em] text-muted">
            Pty Ltd · Fish Hoek
          </span>
        )}
      </span>
    </span>
  );
}
