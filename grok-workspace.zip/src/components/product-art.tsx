import type { CategoryId } from "@/lib/catalogue";
import { cn } from "@/lib/utils";

const palettes: Record<CategoryId, { a: string; b: string; c: string }> = {
  clothing: { a: "var(--color-elevated)", b: "var(--color-primary)", c: "var(--color-cream)" },
  footwear: { a: "var(--color-surface)", b: "var(--color-muted)", c: "var(--color-cream)" },
  network: { a: "var(--color-elevated)", b: "var(--color-primary)", c: "var(--color-fg)" },
  office: { a: "var(--color-surface)", b: "var(--color-muted)", c: "var(--color-paper)" },
  security: { a: "var(--color-bg)", b: "var(--color-muted)", c: "var(--color-cream)" },
  furniture: { a: "var(--color-elevated)", b: "var(--color-subtle)", c: "var(--color-cream)" },
};

export function ProductArt({
  category,
  seed,
  className,
}: {
  category: CategoryId;
  seed: string;
  className?: string;
}) {
  const p = palettes[category];
  const n = seed.split("").reduce((a, ch) => a + ch.charCodeAt(0), 0);
  const rot = (n % 18) - 9;
  const ox = 8 + (n % 10);
  const oy = 6 + ((n * 3) % 12);

  return (
    <div className={cn("relative overflow-hidden rounded-lg bg-elevated", className)} aria-hidden="true">
      <svg viewBox="0 0 160 110" className="size-full">
        <rect width="160" height="110" fill={p.a} />
        <g transform={`translate(${ox} ${oy}) rotate(${rot} 70 50)`}>
          {category === "clothing" ? (
            <>
              <path d="M40 28 L70 18 L100 28 L92 42 L92 88 L48 88 L48 42 Z" fill={p.b} />
              <path d="M70 18 L78 34 L62 34 Z" fill={p.c} opacity="0.7" />
              <rect x="48" y="54" width="44" height="6" fill={p.c} opacity="0.35" />
            </>
          ) : null}
          {category === "footwear" ? (
            <>
              <path d="M28 64 C48 44, 78 44, 118 58 L122 70 C90 78, 50 80, 30 72 Z" fill={p.b} />
              <path d="M34 66 C52 52, 86 52, 116 62" fill="none" stroke={p.c} strokeWidth="3" />
              <rect x="36" y="68" width="70" height="6" rx="3" fill={p.a} opacity="0.4" />
            </>
          ) : null}
          {category === "network" ? (
            <>
              <rect x="36" y="30" width="88" height="52" rx="6" fill={p.b} />
              {Array.from({ length: 8 }).map((_, i) => (
                <rect
                  key={i}
                  x={46 + (i % 4) * 18}
                  y={40 + Math.floor(i / 4) * 18}
                  width="10"
                  height="10"
                  rx="1.5"
                  fill={p.c}
                  opacity={0.45 + ((n + i) % 4) * 0.12}
                />
              ))}
            </>
          ) : null}
          {category === "office" ? (
            <>
              <rect x="42" y="24" width="70" height="62" fill={p.c} />
              <rect x="50" y="32" width="54" height="6" fill={p.b} opacity="0.5" />
              <rect x="50" y="44" width="40" height="4" fill={p.a} opacity="0.35" />
              <rect x="50" y="54" width="46" height="4" fill={p.a} opacity="0.25" />
              <rect x="50" y="64" width="30" height="4" fill={p.a} opacity="0.2" />
            </>
          ) : null}
          {category === "security" ? (
            <>
              <circle cx="80" cy="52" r="28" fill={p.b} />
              <circle cx="80" cy="52" r="14" fill={p.a} />
              <circle cx="80" cy="52" r="6" fill={p.c} />
              <rect x="76" y="18" width="8" height="12" fill={p.c} />
            </>
          ) : null}
          {category === "furniture" ? (
            <>
              <rect x="34" y="48" width="92" height="28" rx="3" fill={p.b} />
              <rect x="40" y="34" width="24" height="18" rx="2" fill={p.c} />
              <rect x="96" y="34" width="24" height="18" rx="2" fill={p.c} />
              <rect x="40" y="76" width="8" height="16" fill={p.a} />
              <rect x="112" y="76" width="8" height="16" fill={p.a} />
            </>
          ) : null}
        </g>
      </svg>
    </div>
  );
}
