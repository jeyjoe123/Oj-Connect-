import { Badge } from "@/components/ui/badge";
import type { InvoiceStatus, QuoteStatus } from "@/lib/store";

const quoteTone: Record<QuoteStatus, "mute" | "live" | "paper" | "warn" | "danger"> = {
  new: "warn",
  quoted: "live",
  awarded: "paper",
  invoiced: "live",
  closed: "mute",
};

const quoteLabel: Record<QuoteStatus, string> = {
  new: "New enquiry",
  quoted: "Quoted",
  awarded: "Awarded",
  invoiced: "Invoiced",
  closed: "Closed",
};

export function QuoteBadge({ status }: { status: QuoteStatus }) {
  return <Badge tone={quoteTone[status]}>{quoteLabel[status]}</Badge>;
}

export function InvoiceBadge({ status }: { status: InvoiceStatus }) {
  return <Badge tone={status === "paid" ? "live" : "warn"}>{status === "paid" ? "Paid" : "Issued"}</Badge>;
}
