import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const tones = {
  mute: "bg-elevated text-muted",
  live: "bg-primary/15 text-primary",
  paper: "bg-cream/10 text-cream",
  warn: "bg-warn/15 text-warn",
  danger: "bg-danger/15 text-danger",
} as const;

export function Badge({
  tone = "mute",
  className,
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: keyof typeof tones }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium uppercase tracking-[0.12em]",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
