import { Link } from "@tanstack/react-router";
import { ProductArt } from "@/components/product-art";
import { buttonVariants } from "@/components/ui/button";
import type { Product } from "@/lib/catalogue";
import { getCategory } from "@/lib/catalogue";
import { leadLabel, zar } from "@/lib/format";
import { useBusinessStore } from "@/lib/store";
import { toast } from "sonner";

export function ProductCard({ product }: { product: Product }) {
  const addToBasket = useBusinessStore((s) => s.addToBasket);
  const category = getCategory(product.category);

  return (
    <article className="flex flex-col rounded-xl bg-surface p-2 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]">
      <Link to="/catalogue/$slug" params={{ slug: product.slug }} className="block">
        <ProductArt category={product.category} seed={product.id} className="aspect-video w-full" />
      </Link>
      <div className="flex flex-1 flex-col px-3 pb-3 pt-4">
        <p className="text-xs uppercase tracking-[0.14em] text-muted">{category.label}</p>
        <Link to="/catalogue/$slug" params={{ slug: product.slug }} className="mt-1 font-medium text-fg">
          {product.name}
        </Link>
        <p className="mt-1 line-clamp-2 text-sm text-muted">{product.summary}</p>
        <div className="mt-auto flex items-end justify-between gap-3 pt-4">
          <div>
            <p className="font-display text-xl tabular-nums tracking-tight">{zar(product.price)}</p>
            <p className="text-xs text-subtle">
              / {product.unit} · {leadLabel(product.leadDays)}
            </p>
          </div>
          <button
            type="button"
            className={buttonVariants({ variant: "primary", size: "sm" })}
            onClick={() => {
              addToBasket(product);
              toast.success(`Added ${product.name} to quote`);
            }}
          >
            Add
          </button>
        </div>
      </div>
    </article>
  );
}
