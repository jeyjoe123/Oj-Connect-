import { COMPANY } from "@/lib/company";
import { formatDateLong, zar } from "@/lib/format";
import { itemsTotal, type Enquiry, type Invoice } from "@/lib/store";
import { Mark } from "@/components/logo";

function DocHead({ title, number, date }: { title: string; number: string; date: string }) {
  return (
    <header className="flex items-start justify-between gap-4 border-b border-ink/15 pb-5">
      <div className="flex items-center gap-3 text-ink">
        <Mark className="size-10" />
        <div>
          <p className="font-display text-xl tracking-tight">{COMPANY.tradingName}</p>
          <p className="text-xs text-ink/60">{COMPANY.legalName}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-ink/50">{title}</p>
        <p className="mt-1 font-display text-2xl tracking-tight text-ink">{number}</p>
        <p className="text-sm text-ink/60">{date}</p>
      </div>
    </header>
  );
}

function Parties({ buyer }: { buyer: Enquiry["buyer"] }) {
  return (
    <div className="mt-6 grid gap-6 sm:grid-cols-2">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-ink/45">From</p>
        <p className="mt-2 text-sm text-ink">
          {COMPANY.legalName}
          <br />
          {COMPANY.street1}
          <br />
          {COMPANY.street2}, {COMPANY.city}
          <br />
          {COMPANY.province} {COMPANY.postalCode}
        </p>
        <p className="mt-2 text-xs text-ink/60">
          CIPC {COMPANY.registrationNumber}
          <br />
          CSD {COMPANY.csdNumber}
          <br />
          Income tax {COMPANY.taxNumber}
        </p>
      </div>
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-ink/45">To</p>
        <p className="mt-2 text-sm text-ink">
          {buyer.org}
          <br />
          {buyer.contact}
          <br />
          {buyer.email}
          <br />
          {buyer.phone}
        </p>
        {buyer.address ? <p className="mt-2 text-xs text-ink/60">{buyer.address}</p> : null}
        {buyer.reference ? (
          <p className="mt-2 text-xs text-ink/60">Your reference: {buyer.reference}</p>
        ) : null}
      </div>
    </div>
  );
}

function Lines({ items }: { items: Enquiry["items"] }) {
  return (
    <table className="mt-8 w-full text-left text-sm">
      <thead>
        <tr className="border-b border-ink/15 text-xs uppercase tracking-[0.12em] text-ink/45">
          <th className="py-2 pr-3 font-medium">Item</th>
          <th className="py-2 pr-3 font-medium">Qty</th>
          <th className="py-2 pr-3 text-right font-medium">Unit</th>
          <th className="py-2 text-right font-medium">Amount</th>
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.productId} className="border-b border-ink/8">
            <td className="py-2.5 pr-3">
              <span className="text-ink">{item.name}</span>
              <span className="mt-0.5 block text-xs text-ink/45">{item.sku}</span>
            </td>
            <td className="py-2.5 pr-3 tabular-nums text-ink">
              {item.qty} {item.unit}
            </td>
            <td className="py-2.5 pr-3 text-right tabular-nums text-ink">{zar(item.unitPrice)}</td>
            <td className="py-2.5 text-right tabular-nums text-ink">
              {zar(item.unitPrice * item.qty)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function Totals({ items }: { items: Enquiry["items"] }) {
  const total = itemsTotal(items);
  return (
    <div className="mt-6 ml-auto w-full max-w-xs text-sm">
      <div className="flex justify-between text-ink/60">
        <span>Subtotal</span>
        <span className="tabular-nums">{zar(total)}</span>
      </div>
      <div className="mt-1 flex justify-between text-ink/60">
        <span>VAT</span>
        <span>Not a VAT vendor</span>
      </div>
      <div className="mt-3 flex justify-between border-t border-ink/15 pt-3 font-medium text-ink">
        <span>Total due (ZAR)</span>
        <span className="tabular-nums">{zar(total)}</span>
      </div>
    </div>
  );
}

export function QuoteDocument({ enquiry }: { enquiry: Enquiry }) {
  const issued = enquiry.status === "new" ? "Enquiry acknowledgement" : "Quotation";
  return (
    <article className="print-sheet rounded-xl bg-paper p-6 text-ink shadow-[var(--shadow-paper)] sm:p-10">
      <DocHead title={issued} number={enquiry.number} date={formatDateLong(enquiry.createdAt)} />
      <Parties buyer={enquiry.buyer} />
      <Lines items={enquiry.items} />
      <Totals items={enquiry.items} />
      <p className="mt-8 text-xs text-ink/55">
        Valid until {formatDateLong(enquiry.validUntil)}. Prices are in South African Rand and exclude VAT
        — {COMPANY.legalName} is not a registered VAT vendor. Lead times confirmed on award.
      </p>
      {enquiry.buyer.notes ? (
        <p className="mt-3 text-xs text-ink/55">Buyer note: {enquiry.buyer.notes}</p>
      ) : null}
    </article>
  );
}

export function InvoiceDocument({ invoice }: { invoice: Invoice }) {
  const b = COMPANY.banking;
  return (
    <article className="print-sheet rounded-xl bg-paper p-6 text-ink shadow-[var(--shadow-paper)] sm:p-10">
      <DocHead title="Tax invoice" number={invoice.number} date={formatDateLong(invoice.issuedAt)} />
      <Parties buyer={invoice.buyer} />
      <p className="mt-4 text-xs text-ink/55">
        Due {formatDateLong(invoice.dueAt)} · Status {invoice.status === "paid" ? "Paid" : "Issued"}
      </p>
      <Lines items={invoice.items} />
      <Totals items={invoice.items} />
      <div className="mt-8 rounded-lg bg-cream/60 p-4 text-sm text-ink">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-ink/45">Payment</p>
        <p className="mt-2">
          {b.accountHolder}
          <br />
          {b.bank} · {b.accountType}
          <br />
          Account {b.accountNumber} · Branch {b.branchCode}
        </p>
        <p className="mt-2 text-xs text-ink/55">
          Use {invoice.number} as the payment reference. {COMPANY.legalName} is not a registered VAT
          vendor — no VAT is charged or claimed on this invoice.
        </p>
      </div>
    </article>
  );
}
