export const CATEGORIES = [
  {
    id: "clothing",
    label: "Clothing",
    csdFamily: "Clothing",
    blurb: "Corporate wear, staff uniforms and branded garments for departments and sites.",
  },
  {
    id: "footwear",
    label: "Footwear",
    csdFamily: "Footwear",
    blurb: "Safety boots and duty shoes specified for municipal, school and site work.",
  },
  {
    id: "network",
    label: "Network & ICT",
    csdFamily: "Data Voice or Multimedia Network Equipment or Platforms and Accessories",
    blurb: "Switches, cabling, Wi-Fi, UPS and voice hardware for offices and campuses.",
  },
  {
    id: "office",
    label: "Office supply",
    csdFamily: "Office supplies — (Office supply)",
    blurb: "Paper, toner, stationery and filing — the daily stock that keeps a bid running.",
  },
  {
    id: "security",
    label: "Security & surveillance",
    csdFamily: "Security surveillance and detection",
    blurb: "CCTV, NVR kits, alarms and access control for buildings and yards.",
  },
  {
    id: "furniture",
    label: "Accommodation furniture",
    csdFamily: "Accommodation furniture",
    blurb: "Beds, wardrobes, desks and lodge seating for hostels, guesthouses and sites.",
  },
] as const;

export type CategoryId = (typeof CATEGORIES)[number]["id"];

export type Product = {
  id: string;
  slug: string;
  sku: string;
  name: string;
  category: CategoryId;
  summary: string;
  description: string;
  unit: string;
  price: number;
  minQty: number;
  leadDays: number;
  featured: boolean;
  specs: { label: string; value: string }[];
};

export const PRODUCTS: Product[] = [
  {
    id: "polo-navy",
    slug: "corporate-polo-navy",
    sku: "OJC-CLO-001",
    name: "Corporate polo — navy",
    category: "clothing",
    summary: "Pique cotton polo with chest embroidery window. Standard municipal colours.",
    description:
      "180 gsm pique polo with taped neck, split hem and a 80 × 40 mm embroidery window. Used for staff, events and site identification. Colour-matched lots available on RFQ.",
    unit: "each",
    price: 189,
    minQty: 10,
    leadDays: 10,
    featured: true,
    specs: [
      { label: "Fabric", value: "180 gsm pique cotton" },
      { label: "Sizes", value: "XS–5XL" },
      { label: "Branding", value: "Embroidery or heat transfer" },
      { label: "MOQ", value: "10 units" },
    ],
  },
  {
    id: "staff-uniform",
    slug: "two-piece-staff-uniform",
    sku: "OJC-CLO-002",
    name: "Two-piece staff uniform",
    category: "clothing",
    summary: "Shirt and trouser set for reception, clinics and municipal counters.",
    description:
      "Easy-care poly-cotton shirt with matching tailored trousers. Supplied as a numbered set per wearer. Alternate fabrics quoted for healthcare and kitchen use.",
    unit: "set",
    price: 620,
    minQty: 5,
    leadDays: 12,
    featured: false,
    specs: [
      { label: "Fabric", value: "Poly-cotton easy care" },
      { label: "Includes", value: "Shirt + trouser" },
      { label: "Sizing", value: "Made to size chart" },
    ],
  },
  {
    id: "hivis-jacket",
    slug: "hi-vis-work-jacket",
    sku: "OJC-CLO-003",
    name: "Hi-vis work jacket",
    category: "clothing",
    summary: "Class 2 high-visibility jacket with reflective tape for roads and yards.",
    description:
      "Waterproof outer with taped seams and 50 mm reflective bands. Issued to field teams and contractors. Logo application quoted separately.",
    unit: "each",
    price: 349,
    minQty: 5,
    leadDays: 7,
    featured: false,
    specs: [
      { label: "Class", value: "SANS 50471 Class 2" },
      { label: "Colour", value: "Fluoro lime / navy" },
      { label: "Weather", value: "Waterproof taped seams" },
    ],
  },
  {
    id: "branded-caps",
    slug: "branded-cap-pack",
    sku: "OJC-CLO-004",
    name: "Branded cap pack (10)",
    category: "clothing",
    summary: "Structured six-panel caps, packed in tens for events and teams.",
    description:
      "Heavy brushed cotton cap with sandwich peak and adjustable strap. Sold in packs of ten. One-colour embroidery included in the pack price.",
    unit: "pack",
    price: 450,
    minQty: 1,
    leadDays: 8,
    featured: false,
    specs: [
      { label: "Pack size", value: "10 caps" },
      { label: "Branding", value: "1-colour embroidery included" },
      { label: "Closure", value: "Adjustable strap" },
    ],
  },
  {
    id: "safety-boots",
    slug: "sabs-safety-boots",
    sku: "OJC-FTW-001",
    name: "SABS steel-toe safety boots",
    category: "footwear",
    summary: "Leather work boot with steel toe cap and oil-resistant sole.",
    description:
      "Full-grain leather boot specified for workshops, parks and construction stores. Steel toe, midsole puncture resistance and an oil-resistant rubber outsole.",
    unit: "pair",
    price: 789,
    minQty: 5,
    leadDays: 5,
    featured: true,
    specs: [
      { label: "Standard", value: "SANS 20345" },
      { label: "Toe cap", value: "Steel" },
      { label: "Sizes", value: "3–13 UK" },
    ],
  },
  {
    id: "oxford-duty",
    slug: "corporate-oxford-shoe",
    sku: "OJC-FTW-002",
    name: "Corporate oxford — black",
    category: "footwear",
    summary: "Duty oxford for office, court and front-of-house staff.",
    description:
      "Leather upper with a non-marking sole. A quieter alternative to a safety boot for indoor posts. Supplied boxed per pair.",
    unit: "pair",
    price: 560,
    minQty: 4,
    leadDays: 7,
    featured: false,
    specs: [
      { label: "Upper", value: "Genuine leather" },
      { label: "Colour", value: "Black" },
      { label: "Sole", value: "Non-marking" },
    ],
  },
  {
    id: "school-leather",
    slug: "school-leather-shoe",
    sku: "OJC-FTW-003",
    name: "School leather shoe",
    category: "footwear",
    summary: "Plain black leather school shoe in bulk size runs.",
    description:
      "Traditional round-toe school shoe with a scuff-resistant finish. Quoted by size run for schools and hostels.",
    unit: "pair",
    price: 320,
    minQty: 10,
    leadDays: 10,
    featured: false,
    specs: [
      { label: "Finish", value: "Scuff-resistant black" },
      { label: "Sizes", value: "1–12 UK" },
      { label: "Supply", value: "Size-run packing" },
    ],
  },
  {
    id: "gig-switch",
    slug: "24-port-gigabit-switch",
    sku: "OJC-NET-001",
    name: "24-port gigabit switch",
    category: "network",
    summary: "Unmanaged 24-port gigabit switch for office floors and server rooms.",
    description:
      "Fanless 24× 10/100/1000 RJ45 switch in a 1U metal chassis. Used as the workhorse edge switch on municipal and school networks.",
    unit: "each",
    price: 1890,
    minQty: 1,
    leadDays: 5,
    featured: true,
    specs: [
      { label: "Ports", value: "24 × Gigabit RJ45" },
      { label: "Form", value: "1U metal, fanless" },
      { label: "Mount", value: "Rack ears included" },
    ],
  },
  {
    id: "cat6-drum",
    slug: "cat6-utp-305m-drum",
    sku: "OJC-NET-002",
    name: "Cat6 UTP 305 m drum",
    category: "network",
    summary: "Solid-core Cat6 on a 305 metre pull box for structured cabling.",
    description:
      "23 AWG solid copper Cat6, 250 MHz, supplied on a 305 m reel. Flame-rated jacket suitable for office risers.",
    unit: "drum",
    price: 2450,
    minQty: 1,
    leadDays: 4,
    featured: false,
    specs: [
      { label: "Length", value: "305 m" },
      { label: "Conductor", value: "23 AWG solid Cu" },
      { label: "Rating", value: "Cat6 / 250 MHz" },
    ],
  },
  {
    id: "wifi6-ap",
    slug: "wifi-6-access-point",
    sku: "OJC-NET-003",
    name: "Wi-Fi 6 access point",
    category: "network",
    summary: "Ceiling AP with PoE for classrooms, clinics and open-plan floors.",
    description:
      "Dual-band Wi-Fi 6 access point with gigabit PoE. Ceiling or wall mount. Controller optional — works standalone for small sites.",
    unit: "each",
    price: 1650,
    minQty: 2,
    leadDays: 6,
    featured: false,
    specs: [
      { label: "Radio", value: "Wi-Fi 6 dual-band" },
      { label: "Uplink", value: "1G PoE" },
      { label: "Mount", value: "Ceiling / wall" },
    ],
  },
  {
    id: "ups-1kva",
    slug: "1kva-line-interactive-ups",
    sku: "OJC-NET-004",
    name: "1 kVA line-interactive UPS",
    category: "network",
    summary: "Tower UPS for a reception PC, till or small switch stack.",
    description:
      "Line-interactive UPS with AVR, USB signalling and a lead-acid battery. Covers short Cape Town load events for a single workstation or 8-port switch.",
    unit: "each",
    price: 2100,
    minQty: 1,
    leadDays: 5,
    featured: false,
    specs: [
      { label: "Capacity", value: "1 kVA / 600 W" },
      { label: "Topology", value: "Line-interactive + AVR" },
      { label: "Outlets", value: "4 × SA 3-pin" },
    ],
  },
  {
    id: "ip-phone",
    slug: "ip-desk-phone",
    sku: "OJC-NET-005",
    name: "IP desk phone",
    category: "network",
    summary: "PoE handset for switchboards, clinics and bid offices.",
    description:
      "Two-line IP phone with a backlit display and a gigabit pass-through port. Provisioned against most hosted PABX platforms.",
    unit: "each",
    price: 890,
    minQty: 2,
    leadDays: 6,
    featured: false,
    specs: [
      { label: "Lines", value: "2 SIP accounts" },
      { label: "Power", value: "PoE or PSU" },
      { label: "Network", value: "Gigabit PC port" },
    ],
  },
  {
    id: "a4-carton",
    slug: "a4-copy-paper-carton",
    sku: "OJC-OFF-001",
    name: "A4 copy paper — 5-ream carton",
    category: "office",
    summary: "80 gsm white bond, five reams to a carton. The standing stationery buy.",
    description:
      "80 gsm white A4, 500 sheets per ream, five reams per carton. Suitable for copiers and laser printers used in bid offices.",
    unit: "carton",
    price: 429,
    minQty: 4,
    leadDays: 3,
    featured: true,
    specs: [
      { label: "Weight", value: "80 gsm" },
      { label: "Pack", value: "5 × 500 sheets" },
      { label: "Size", value: "A4" },
    ],
  },
  {
    id: "toner-pack",
    slug: "compatible-toner-pack",
    sku: "OJC-OFF-002",
    name: "Compatible toner pack",
    category: "office",
    summary: "High-yield compatible cartridges quoted against your printer list.",
    description:
      "Compatible laser toner packed per model. Send the printer fleet list with the RFQ and we match yield and fitment. Originals quoted on request.",
    unit: "pack",
    price: 780,
    minQty: 1,
    leadDays: 4,
    featured: false,
    specs: [
      { label: "Type", value: "Compatible laser" },
      { label: "Match", value: "Against fleet list" },
      { label: "Yield", value: "High-yield where available" },
    ],
  },
  {
    id: "stationery-kit",
    slug: "executive-stationery-kit",
    sku: "OJC-OFF-003",
    name: "Desk stationery kit",
    category: "office",
    summary: "Pens, folders, clips and pads packed as a new-starter kit.",
    description:
      "A counted kit for a new desk: writing instruments, A4 pads, suspension files, clips and a stapler. Used for onboarding and satellite offices.",
    unit: "kit",
    price: 245,
    minQty: 5,
    leadDays: 3,
    featured: false,
    specs: [
      { label: "Contents", value: "Counted 18-item kit" },
      { label: "Use", value: "New starter / satellite" },
    ],
  },
  {
    id: "filing-cabinet",
    slug: "four-drawer-filing-cabinet",
    sku: "OJC-OFF-004",
    name: "Four-drawer filing cabinet",
    category: "office",
    summary: "Lockable steel cabinet for personnel and tender files.",
    description:
      "Fully assembled steel cabinet with anti-tilt and a lock bar. Foolscap hanging files sit flush. Powder-coated in grey.",
    unit: "each",
    price: 2890,
    minQty: 1,
    leadDays: 8,
    featured: false,
    specs: [
      { label: "Drawers", value: "4 foolscap" },
      { label: "Lock", value: "Central lock bar" },
      { label: "Finish", value: "Grey powder coat" },
    ],
  },
  {
    id: "nvr-kit",
    slug: "eight-channel-nvr-camera-kit",
    sku: "OJC-SEC-001",
    name: "8-channel NVR kit + 4 cameras",
    category: "security",
    summary: "PoE NVR with four 4 MP turrets, 1 TB storage and night IR.",
    description:
      "A starter site kit: 8-channel PoE NVR, four 4 MP turret cameras, 1 TB disk and 20 m patch leads. Expandable to eight cameras on the same recorder.",
    unit: "kit",
    price: 6450,
    minQty: 1,
    leadDays: 6,
    featured: true,
    specs: [
      { label: "Recorder", value: "8-ch PoE NVR" },
      { label: "Cameras", value: "4 × 4 MP turret" },
      { label: "Storage", value: "1 TB included" },
    ],
  },
  {
    id: "turret-4mp",
    slug: "4mp-turret-camera",
    sku: "OJC-SEC-002",
    name: "4 MP turret camera",
    category: "security",
    summary: "IP turret with 30 m IR for yards, corridors and parking.",
    description:
      "Metal turret, 4 MP, 2.8 mm lens, 30 m IR. PoE. Used as a drop-in extra on the 8-channel kit or as a replacement head.",
    unit: "each",
    price: 890,
    minQty: 2,
    leadDays: 5,
    featured: false,
    specs: [
      { label: "Sensor", value: "4 MP" },
      { label: "IR", value: "30 m" },
      { label: "Power", value: "PoE" },
    ],
  },
  {
    id: "alarm-kit",
    slug: "wireless-alarm-kit",
    sku: "OJC-SEC-003",
    name: "Wireless alarm kit",
    category: "security",
    summary: "Panel, keypad, PIR and door contacts for a small building.",
    description:
      "App-connected wireless alarm with a keypad, two PIRs, two door contacts and a siren. Suitable for a satellite office or storeroom.",
    unit: "kit",
    price: 2150,
    minQty: 1,
    leadDays: 5,
    featured: false,
    specs: [
      { label: "Includes", value: "Panel, keypad, 2 PIR, 2 contacts, siren" },
      { label: "App", value: "iOS / Android" },
    ],
  },
  {
    id: "access-rfid",
    slug: "rfid-access-control-kit",
    sku: "OJC-SEC-004",
    name: "RFID access control kit",
    category: "security",
    summary: "Single-door controller, reader, lock and ten fobs.",
    description:
      "A complete single-door kit: controller, Wiegand reader, magnetic lock, override key and ten fobs. Extra doors quoted per opening.",
    unit: "kit",
    price: 3200,
    minQty: 1,
    leadDays: 7,
    featured: false,
    specs: [
      { label: "Doors", value: "1 (expandable)" },
      { label: "Lock", value: "Maglock included" },
      { label: "Fobs", value: "10" },
    ],
  },
  {
    id: "bed-set",
    slug: "single-bed-mattress-set",
    sku: "OJC-FUR-001",
    name: "Single bed + mattress set",
    category: "furniture",
    summary: "Steel-frame single with a medium-firm inner-spring mattress.",
    description:
      "Powder-coated steel single bed with a 137 mm inner-spring mattress. Specified for hostels, lodges and site accommodation. Stackable headboards optional.",
    unit: "set",
    price: 3450,
    minQty: 2,
    leadDays: 10,
    featured: true,
    specs: [
      { label: "Size", value: "Single 92 × 188 cm" },
      { label: "Mattress", value: "Inner spring, medium" },
      { label: "Frame", value: "Steel, powder coated" },
    ],
  },
  {
    id: "wardrobe-3",
    slug: "three-door-wardrobe",
    sku: "OJC-FUR-002",
    name: "Three-door wardrobe",
    category: "furniture",
    summary: "Melamine wardrobe with hanging rail and two shelves.",
    description:
      "16 mm melamine three-door wardrobe, hanging rail on the left, two shelves on the right. Knock-down packed for site delivery.",
    unit: "each",
    price: 4890,
    minQty: 1,
    leadDays: 12,
    featured: false,
    specs: [
      { label: "Board", value: "16 mm melamine" },
      { label: "Doors", value: "3" },
      { label: "Pack", value: "Knock-down" },
    ],
  },
  {
    id: "study-desk",
    slug: "study-desk-and-chair",
    sku: "OJC-FUR-003",
    name: "Study desk + chair",
    category: "furniture",
    summary: "Compact desk and stacking chair for hostels and training rooms.",
    description:
      "1 200 mm melamine desk with a steel-frame stacking chair. Used in residences, training rooms and bid-office overflow.",
    unit: "set",
    price: 2150,
    minQty: 2,
    leadDays: 9,
    featured: false,
    specs: [
      { label: "Desk", value: "1 200 × 600 mm" },
      { label: "Chair", value: "Stacking, steel frame" },
    ],
  },
  {
    id: "lodge-sofa",
    slug: "three-seater-lodge-sofa",
    sku: "OJC-FUR-004",
    name: "Three-seater lodge sofa",
    category: "furniture",
    summary: "Contract fabric sofa for lounges, waiting rooms and guesthouses.",
    description:
      "Hardwood frame, high-density foam and a contract-grade fabric. Specified for waiting rooms and lodge lounges that take daily traffic.",
    unit: "each",
    price: 6200,
    minQty: 1,
    leadDays: 14,
    featured: false,
    specs: [
      { label: "Seats", value: "3" },
      { label: "Fabric", value: "Contract grade" },
      { label: "Frame", value: "Hardwood" },
    ],
  },
];

export function getCategory(id: CategoryId) {
  return CATEGORIES.find((c) => c.id === id)!;
}

export function getProduct(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function getProductById(id: string) {
  return PRODUCTS.find((p) => p.id === id);
}

export function productsIn(id: CategoryId) {
  return PRODUCTS.filter((p) => p.category === id);
}

export function featuredProducts() {
  return PRODUCTS.filter((p) => p.featured);
}
