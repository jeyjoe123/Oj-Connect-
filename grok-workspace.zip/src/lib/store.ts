import { create } from "zustand";
import { persist } from "zustand/middleware";
import { PRODUCTS, type Product } from "@/lib/catalogue";
import { daysFromNow } from "@/lib/format";

export type QuoteStatus = "new" | "quoted" | "awarded" | "invoiced" | "closed";
export type InvoiceStatus = "issued" | "paid";

export type LineItem = {
  productId: string;
  name: string;
  sku: string;
  unit: string;
  unitPrice: number;
  qty: number;
};

export type Buyer = {
  org: string;
  contact: string;
  email: string;
  phone: string;
  address: string;
  reference: string;
  notes: string;
};

export type Enquiry = {
  id: string;
  number: string;
  createdAt: string;
  status: QuoteStatus;
  buyer: Buyer;
  items: LineItem[];
  validUntil: string;
  internalNote: string;
};

export type Invoice = {
  id: string;
  number: string;
  enquiryId: string;
  issuedAt: string;
  dueAt: string;
  status: InvoiceStatus;
  buyer: Buyer;
  items: LineItem[];
};

export type Message = {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  body: string;
  createdAt: string;
  read: boolean;
};

type BusinessState = {
  hydrated: boolean;
  basket: LineItem[];
  enquiries: Enquiry[];
  invoices: Invoice[];
  messages: Message[];
  enquirySeq: number;
  invoiceSeq: number;
  messageSeq: number;
  markHydrated: () => void;
  addToBasket: (product: Product, qty?: number) => void;
  setBasketQty: (productId: string, qty: number) => void;
  removeFromBasket: (productId: string) => void;
  clearBasket: () => void;
  submitEnquiry: (buyer: Buyer) => Enquiry;
  setEnquiryStatus: (id: string, status: QuoteStatus) => void;
  setItemPrice: (enquiryId: string, productId: string, unitPrice: number) => void;
  setItemQty: (enquiryId: string, productId: string, qty: number) => void;
  setInternalNote: (id: string, note: string) => void;
  issueQuote: (id: string) => void;
  raiseInvoice: (enquiryId: string) => Invoice | null;
  markInvoicePaid: (id: string) => void;
  addMessage: (input: Omit<Message, "id" | "createdAt" | "read">) => Message;
  markMessageRead: (id: string) => void;
  restoreSample: () => void;
};

function pad(n: number) {
  return String(n).padStart(4, "0");
}

function lineFromProduct(product: Product, qty: number): LineItem {
  return {
    productId: product.id,
    name: product.name,
    sku: product.sku,
    unit: product.unit,
    unitPrice: product.price,
    qty,
  };
}

function findProduct(id: string) {
  return PRODUCTS.find((p) => p.id === id)!;
}

const SEED_ENQUIRIES: Enquiry[] = [
  {
    id: "enq-1",
    number: "Q-2026-0001",
    createdAt: "2026-09-12T09:14:00.000Z",
    status: "awarded",
    validUntil: "2026-09-26T00:00:00.000Z",
    internalNote: "Awarded against City of Cape Town RFQ-PRK-441. Delivery to Fish Hoek depot.",
    buyer: {
      org: "City of Cape Town — Parks & Recreation",
      contact: "Lindiwe September",
      email: "procurement.parks@capetown.gov.za",
      phone: "021 400 1111",
      address: "Civic Centre, 12 Hertzog Boulevard, Cape Town, 8001",
      reference: "RFQ-PRK-441",
      notes: "Hi-vis and safety boots for the southern peninsula crew. Delivered to Fish Hoek depot.",
    },
    items: [
      lineFromProduct(findProduct("hivis-jacket"), 24),
      lineFromProduct(findProduct("safety-boots"), 24),
    ],
  },
  {
    id: "enq-2",
    number: "Q-2026-0002",
    createdAt: "2026-09-18T11:40:00.000Z",
    status: "quoted",
    validUntil: "2026-10-02T00:00:00.000Z",
    internalNote: "Waiting on SGB sign-off.",
    buyer: {
      org: "Fish Hoek Primary School",
      contact: "Thabo Ndlovu",
      email: "admin@fishhoekps.wcape.school.za",
      phone: "021 782 2104",
      address: "18 2nd Avenue, Fish Hoek, 7975",
      reference: "SGB-STAT-09",
      notes: "Term-four stationery and two filing cabinets for the office.",
    },
    items: [
      lineFromProduct(findProduct("a4-carton"), 12),
      lineFromProduct(findProduct("stationery-kit"), 8),
      lineFromProduct(findProduct("filing-cabinet"), 2),
    ],
  },
  {
    id: "enq-3",
    number: "Q-2026-0003",
    createdAt: "2026-09-22T08:05:00.000Z",
    status: "new",
    validUntil: "2026-10-06T00:00:00.000Z",
    internalNote: "",
    buyer: {
      org: "False Bay Lodge",
      contact: "Mila Jacobs",
      email: "stay@falsebaylodge.co.za",
      phone: "082 441 9022",
      address: "Main Road, Kalk Bay, 7975",
      reference: "LODGE-FURN-26",
      notes: "Four guest rooms to furnish before December. Need beds, wardrobes and a lounge sofa.",
    },
    items: [
      lineFromProduct(findProduct("bed-set"), 4),
      lineFromProduct(findProduct("wardrobe-3"), 4),
      lineFromProduct(findProduct("lodge-sofa"), 1),
    ],
  },
];

const SEED_INVOICES: Invoice[] = [
  {
    id: "inv-1",
    number: "INV-2026-0001",
    enquiryId: "enq-seed-paid",
    issuedAt: "2026-08-28T10:00:00.000Z",
    dueAt: "2026-09-11T00:00:00.000Z",
    status: "paid",
    buyer: {
      org: "Masiphumelele Community Trust",
      contact: "Nomsa Dlamini",
      email: "ops@mct.org.za",
      phone: "021 785 3340",
      address: "Community Hall, Masiphumelele, Fish Hoek, 7975",
      reference: "MCT-ICT-08",
      notes: "",
    },
    items: [
      lineFromProduct(findProduct("gig-switch"), 2),
      lineFromProduct(findProduct("wifi6-ap"), 4),
      lineFromProduct(findProduct("cat6-drum"), 2),
    ],
  },
];

function sampleState() {
  return {
    basket: [] as LineItem[],
    enquiries: SEED_ENQUIRIES,
    invoices: SEED_INVOICES,
    messages: [] as Message[],
    enquirySeq: 4,
    invoiceSeq: 2,
    messageSeq: 1,
  };
}

export function lineTotal(item: LineItem) {
  return item.unitPrice * item.qty;
}

export function itemsTotal(items: LineItem[]) {
  return items.reduce((sum, item) => sum + lineTotal(item), 0);
}

export const useBusinessStore = create<BusinessState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      ...sampleState(),
      markHydrated: () => set({ hydrated: true }),
      addToBasket: (product, qty) => {
        const addQty = Math.max(qty ?? product.minQty, product.minQty);
        set((state) => {
          const existing = state.basket.find((i) => i.productId === product.id);
          if (existing) {
            return {
              basket: state.basket.map((i) =>
                i.productId === product.id ? { ...i, qty: i.qty + addQty } : i,
              ),
            };
          }
          return { basket: [...state.basket, lineFromProduct(product, addQty)] };
        });
      },
      setBasketQty: (productId, qty) => {
        const product = PRODUCTS.find((p) => p.id === productId);
        const min = product?.minQty ?? 1;
        set((state) => ({
          basket: state.basket
            .map((i) =>
              i.productId === productId ? { ...i, qty: Math.max(min, qty) } : i,
            )
            .filter((i) => i.qty > 0),
        }));
      },
      removeFromBasket: (productId) =>
        set((state) => ({
          basket: state.basket.filter((i) => i.productId !== productId),
        })),
      clearBasket: () => set({ basket: [] }),
      submitEnquiry: (buyer) => {
        const { basket, enquirySeq } = get();
        const enquiry: Enquiry = {
          id: `enq-${Date.now()}`,
          number: `Q-2026-${pad(enquirySeq)}`,
          createdAt: new Date().toISOString(),
          status: "new",
          buyer,
          items: basket.map((i) => ({ ...i })),
          validUntil: daysFromNow(14),
          internalNote: "",
        };
        set({
          enquiries: [enquiry, ...get().enquiries],
          enquirySeq: enquirySeq + 1,
          basket: [],
        });
        return enquiry;
      },
      setEnquiryStatus: (id, status) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) => (e.id === id ? { ...e, status } : e)),
        })),
      setItemPrice: (enquiryId, productId, unitPrice) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) =>
            e.id === enquiryId
              ? {
                  ...e,
                  items: e.items.map((i) =>
                    i.productId === productId
                      ? { ...i, unitPrice: Math.max(0, unitPrice) }
                      : i,
                  ),
                }
              : e,
          ),
        })),
      setItemQty: (enquiryId, productId, qty) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) =>
            e.id === enquiryId
              ? {
                  ...e,
                  items: e.items.map((i) =>
                    i.productId === productId ? { ...i, qty: Math.max(1, qty) } : i,
                  ),
                }
              : e,
          ),
        })),
      setInternalNote: (id, note) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) =>
            e.id === id ? { ...e, internalNote: note } : e,
          ),
        })),
      issueQuote: (id) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) =>
            e.id === id
              ? {
                  ...e,
                  status: e.status === "new" ? "quoted" : e.status,
                  validUntil: daysFromNow(14),
                }
              : e,
          ),
        })),
      raiseInvoice: (enquiryId) => {
        const enquiry = get().enquiries.find((e) => e.id === enquiryId);
        if (!enquiry) return null;
        const existing = get().invoices.find((i) => i.enquiryId === enquiryId);
        if (existing) return existing;
        const invoice: Invoice = {
          id: `inv-${Date.now()}`,
          number: `INV-2026-${pad(get().invoiceSeq)}`,
          enquiryId,
          issuedAt: new Date().toISOString(),
          dueAt: daysFromNow(14),
          status: "issued",
          buyer: enquiry.buyer,
          items: enquiry.items.map((i) => ({ ...i })),
        };
        set({
          invoices: [invoice, ...get().invoices],
          invoiceSeq: get().invoiceSeq + 1,
          enquiries: get().enquiries.map((e) =>
            e.id === enquiryId ? { ...e, status: "invoiced" } : e,
          ),
        });
        return invoice;
      },
      markInvoicePaid: (id) =>
        set((state) => ({
          invoices: state.invoices.map((i) =>
            i.id === id ? { ...i, status: "paid" } : i,
          ),
        })),
      addMessage: (input) => {
        const message: Message = {
          ...input,
          id: `msg-${Date.now()}`,
          createdAt: new Date().toISOString(),
          read: false,
        };
        set({
          messages: [message, ...get().messages],
          messageSeq: get().messageSeq + 1,
        });
        return message;
      },
      markMessageRead: (id) =>
        set((state) => ({
          messages: state.messages.map((m) => (m.id === id ? { ...m, read: true } : m)),
        })),
      restoreSample: () => set(sampleState()),
    }),
    {
      name: "oj-connect-desk",
      skipHydration: true,
      partialize: (state) => ({
        basket: state.basket,
        enquiries: state.enquiries,
        invoices: state.invoices,
        messages: state.messages,
        enquirySeq: state.enquirySeq,
        invoiceSeq: state.invoiceSeq,
        messageSeq: state.messageSeq,
      }),
    },
  ),
);
